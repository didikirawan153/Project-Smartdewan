<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
	<title>Download Script Form Input Tanggal | Tutorial</title>
	<style type="text/css" media="screen">
		table {font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;}
		input {font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 11px;height: 20px;}
		a:link{color: #000}
		p{margin:10px 0 0 0;}
		h2{margin:0 0 10px 0;}
	</style>
</head>
<body>
<br />
<h2>Script Form Input Tanggal | Tutorial</h2>
<hr>
<br />
<center>
<div style="border:1px solid #FFA800; padding:10px; overflow:auto; width:600px; height:320px;">
<form action="#" method="POST" name="forminputtanggal" enctype="multipart/form-data">
	<table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr height="46">
			<td><font color="orange" size="2"><b>FORM INPUT TANGGAL</b></font></td>
		</tr>
	</table>
	<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr height="36">
			<td>&nbsp;</td>
			<td>Tanggal</td>
			<td><input name="tgl_upload" value="" size="24">&nbsp;<a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.forminputtanggal.tgl_upload);return false;" ><img name="popcal" align="absmiddle" src="calender/calbtn.gif" width="34" height="22" border="0" alt=""></a></td>
		</tr>
		<tr height="36">
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td><input type="submit" name="Submit" value="Submit">&nbsp;&nbsp;&nbsp;
				<input type="reset" name="reset" value="Reset"></td>
		</tr>
	</table>
</form>
</div>
<iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="calender/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;">
</iframe></center>
<br />
<p align="center" style="margin:0 0 10px 0;">
	<font face="vijaya">Copyright &copy; 2013. All Rights Reserved. <a href="http://www.rajaputramedia.com">Jasa Pembuatan Website</a> - Raja Putra Media</font>
</p>
</body>
</html>