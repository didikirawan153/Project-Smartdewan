<?php
if($_GET['act']=="input"){
	?>
          <div class="row">
                <div class="col-lg-12">
					<h3 class="page-header"><strong>Input Data Pengumuman</strong></h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Input Data Pengumuman
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                    <form method="post" role="form" action="././module/simpan.php?act=input_pengumuman">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Judul Pengumuman</label>
                                            <input class="form-control" placeholder="Judul" name="judul">
                                        </div>
                                       
                                        <div class="form-group">
                                            <label>Deskripsi Pengumuman</label>
                                            <textarea class="form-control" placeholder="Deskripsi" name="deskripsi" rows="3"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label>Dimulai Tanggal : </label>
                                            <select name="tanggal">
  <?php 
	$sql=mysql_query("select * from tanggal");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	
    }
    }else{
		echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                            <select name="bulan">
  <?php 
	$sql=mysql_query("select * from bulan");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	
    }
    }else{
		echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                          <select name="tahun">
  <?php 
	$sql=mysql_query("select * from tahun");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	
    }
    }else{
		echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	

	}
    }
    ?>
                                          </select>
                                        </div>


                                        <div class="form-group">
                                            <label>Berakhir Tanggal : </label>
                                            <select name="tanggalakhir">
  <?php 
	$sql=mysql_query("select * from tanggal");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	
    }
    }else{
		echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                            <select name="bulanakhir">
  <?php 
	$sql=mysql_query("select * from bulan");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	
    }
    }else{
		echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                          <select name="tahunakhir">
  <?php 
	$sql=mysql_query("select * from tahun");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	
    }
    }else{
		echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	

	}
    }
    ?>
                                          </select>
                                        </div>

                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           <?php } ?>
           
           
           
           <?php
if($_GET['act']=="edit_pengumuman"){
	?>
          <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Data Pengumuman</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Data Pengumuman
                        </div>
                        <div class="panel-body">
                            <div class="row">
<?php                            
                            	$sql=mysql_query("select * from pengumuman where idp='$_GET[idp]'");
								$rs=mysql_fetch_array($sql);

?>
                                    <form method="post" role="form" action="././module/simpan.php?act=edit_pengumuman">
<input type="hidden" name="idp" value="<?php echo $_GET['idp'] ?>" />

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Judul Pengumuman</label>
                                            <input class="form-control" placeholder="Kode" name="judul" value="<?php echo "$rs[judul]"; ?>">
</div>
                                        
                                        
                                        <div class="form-group">
                                        <label>Deskripsi Pengumuman</label>
                                            <textarea class="form-control" placeholder="Alamat" name="deskripsi" rows="3"><?php echo "$rs[deskripsi]"; ?></textarea>
                                        </div>


                                        <div class="form-group">
                                            <label>Dimulai Tanggal : </label>
                                            <select name="tanggal">
  <?php 
	$sql=mysql_query("select * from tanggal");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	
    }
    }else{
		echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                            <select name="bulan">
  <?php 
	$sql=mysql_query("select * from bulan");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	
    }
    }else{
		echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                          <select name="tahun">
  <?php 
	$sql=mysql_query("select * from tahun");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	
    }
    }else{
		echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	

	}
    }
    ?>
                                          </select>
                                        </div>


                                        <div class="form-group">
                                            <label>Berakhir Tanggal : </label>
                                            <select name="tanggalakhir">
  <?php 
	$sql=mysql_query("select * from tanggal");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	
    }
    }else{
		echo "<option value='$rshr[tanggal]'>$rshr[tanggal]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                            <select name="bulanakhir">
  <?php 
	$sql=mysql_query("select * from bulan");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	
    }
    }else{
		echo "<option value='$rshr[bulan]'>$rshr[bulan]</option>";	

	}
    }
    ?>
                                          </select>

                                          <label> </label>
                                          <select name="tahunakhir">
  <?php 
	$sql=mysql_query("select * from tahun");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	
    }
    }else{
		echo "<option value='$rshr[tahun]'>$rshr[tahun]</option>";	

	}
    }
    ?>
                                          </select>
                                        </div>

                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php } ?>
             