<?php
if($_GET['act']=="input"){
	?>
          <div class="row">
                <div class="col-lg-12">
					<h3 class="page-header"><strong>Input Data Jadwal</strong></h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Input Data Jadwal
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                    <form method="post" role="form" action="././module/simpan.php?act=input_jadwal">

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Nama Kelas</label>
                                            <select class="form-control" name="kelas_jadwal">
  <?php 
	$sql=mysql_query("select * from kelas");
	while($rs=mysql_fetch_array($sql)){
if($_SESSION['level']=="admin_guru"){
if($rs['id']==$_SESSION['id']){
		
	echo "<option value='$rs[nama]'>$rs[nama]</option>";	
}
}else{
		echo "<option value='$rs[nama]'>$rs[nama]</option>";	

	}
}
?>
                                          </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Guru</label>
                                            <select class="form-control" name="guru">
  <?php 
	$sql=mysql_query("select * from guru");
	while($rsg=mysql_fetch_array($sql)){
if($_SESSION['level']=="admin_guru"){
if($rsg['id']==$_SESSION['id']){
		
	echo "<option value='$rsg[nama]'>$rsg[nama]</option>";	
}
}else{
		echo "<option value='$rsg[nama]'>$rsg[nama]</option>";	

	}
}
?>
                                          </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Mata Pelajaran</label>
                                            <select class="form-control" name="mapel">
  <?php 
	$sql=mysql_query("select * from pelajaran");
	while($rsm=mysql_fetch_array($sql)){
if($_SESSION['level']=="admin_guru"){
if($rsm['id']==$_SESSION['id']){
		
	echo "<option value='$rsm[nama_mapel]'>$rsm[nama_mapel]</option>";	
}
}else{
		echo "<option value='$rsm[nama_mapel]'>$rsm[nama_mapel]</option>";	

	}
}
?>
                                          </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Hari</label>
                                            <select name="hari">
  <?php 
	$sql=mysql_query("select * from hari");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[nama_hari]'>$rshr[nama_hari]</option>";	
    }
    }else{
		echo "<option value='$rshr[nama_hari]'>$rshr[nama_hari]</option>";	

	}
    }
    ?>
                                          </select>

                                          
                                        <label>Jam Ke</label>
                                        <select name="jam">
  <?php 
	$sql=mysql_query("select * from jam");
	while($rshr=mysql_fetch_array($sql)){
    if($_SESSION['level']=="admin_guru"){
    if($rshr['id']==$_SESSION['id']){
		
	echo "<option value='$rshr[jam_ke]'>$rshr[jam_ke]</option>";	
    }
    }else{
		echo "<option value='$rshr[jam_ke]'>$rshr[jam_ke]</option>";	

	}
    }
    ?>
                                          </select>
                                        
                                        </div>

                                        

                                

                                        <button type="submit" class="btn btn-default">Simpan Data</button>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
           <?php } ?>
           
           
           
           <?php
if($_GET['act']=="edit_jadwal"){
	?>
          <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Data Jadwal</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Data Jadwal
                        </div>
                        <div class="panel-body">
                            <div class="row">
<?php                            
                            	$sql=mysql_query("select * from jadwal where id_jadwal='$_GET[idj]'");
								$rs=mysql_fetch_array($sql);

?>
                                    <form method="post" role="form" action="././module/simpan.php?act=edit_jadwal">
<input type="hidden" name="idj" value="<?php echo $_GET['idj'] ?>" />

                                <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Kelas</label>
                                            <select class="form-control" name="kelas_jadwal">
  <?php 
	$sqla=mysql_query("select * from kelas");
	while($rsa=mysql_fetch_array($sqla)){
if($_SESSION['level']=="admin_guru"){
if($rsa['id']==$_SESSION['id']){

if($rs['kelas']==$rsa['nama']){

	echo "<option value='$rsa[nama]' selected='selected'>$rsa[nama]</option>";	
}else{
	echo "<option value='$rsa[nama]'>$rsa[nama]</option>";		
}

}
}else{
if($rs['kelas']==$rsa['nama']){

	echo "<option value='$rsa[nama]' selected='selected'>$rsa[nama]</option>";	
}else{
	echo "<option value='$rsa[nama]'>$rsa[nama]</option>";		
}

}
}
?>
                                          </select>
                                </div>

                                <div class="form-group">
                                            <label>Nama Guru</label>
                                            <select class="form-control" name="guru">
  <?php 
	$sqla=mysql_query("select * from guru");
	while($rsg=mysql_fetch_array($sqla)){
if($_SESSION['level']=="admin_guru"){
if($rsg['id']==$_SESSION['id']){

if($rs['guru']==$rsg['nama']){

	echo "<option value='$rsg[nama]' selected='selected'>$rsg[nama]</option>";	
}else{
	echo "<option value='$rsg[nama]'>$rsg[nama]</option>";		
}

}
}else{
if($rs['guru']==$rsg['nama']){

	echo "<option value='$rsg[nama]' selected='selected'>$rsg[nama]</option>";	
}else{
	echo "<option value='$rsg[nama]'>$rsg[nama]</option>";		
}

}
}
?>
                                          </select>
                                </div>

                                <div class="form-group">
                                            <label>Mata Pelajaran</label>
                                            <select class="form-control" name="mapel">
  <?php 
	$sqla=mysql_query("select * from pelajaran");
	while($rsa=mysql_fetch_array($sqla)){
if($_SESSION['level']=="admin_guru"){
if($rsa['id']==$_SESSION['id']){

if($rs['mapel']==$rsa['nama_mapel']){

	echo "<option value='$rsa[nama_mapel]' selected='selected'>$rsa[nama_mapel]</option>";	
}else{
	echo "<option value='$rsa[nama_mapel]'>$rsa[nama_mapel]</option>";		
}

}
}else{
if($rs['mapel']==$rsa['nama_mapel']){

	echo "<option value='$rsa[nama_mapel]' selected='selected'>$rsa[nama_mapel]</option>";	
}else{
	echo "<option value='$rsa[nama_mapel]'>$rsa[nama_mapel]</option>";		
}

}
}
?>
                                          </select>
                                </div>

                                <div class="form-group">
                                            <label>Hari</label>
                                            <select name="hari">
  <?php 
	$sqla=mysql_query("select * from hari");
	while($rsa=mysql_fetch_array($sqla)){
if($_SESSION['level']=="admin_guru"){
if($rsa['id']==$_SESSION['id']){

if($rs['hari']==$rsa['nama_hari']){

	echo "<option value='$rsa[nama_hari]' selected='selected'>$rsa[nama_hari]</option>";	
}else{
	echo "<option value='$rsa[nama_hari]'>$rsa[nama_hari]</option>";		
}

}
}else{
if($rs['hari']==$rsa['nama_hari']){

	echo "<option value='$rsa[nama_hari]' selected='selected'>$rsa[nama_hari]</option>";	
}else{
	echo "<option value='$rsa[nama_hari]'>$rsa[nama_hari]</option>";		
}

}
}
?>
                                          </select>
                                
                                            <label>Jam</label>
                                            <select name="jam">
  <?php 
$sqla=mysql_query("select * from jam");
while($rsa=mysql_fetch_array($sqla)){
if($_SESSION['level']=="admin_guru"){
if($rsa['id']==$_SESSION['id']){

if($rs['jam_ke']==$rsa['jam_ke']){

echo "<option value='$rsa[jam_ke]' selected='selected'>$rsa[jam_ke]</option>";	
}else{
echo "<option value='$rsa[jam_ke]'>$rsa[jam_ke]</option>";		
}

}
}else{
if($rs['jam_ke']==$rsa['jam_ke']){
echo "<option value='$rsa[jam_ke]' selected='selected'>$rsa[jam_ke]</option>";	
}else{
echo "<option value='$rsa[jam_ke]'>$rsa[jam_ke]</option>";		
}

}
}
?>
                                          </select>
                                </div>


                                <button type="submit" class="btn btn-default">Submit Button</button>


                                <!-- /.col-lg-6 (nested) -->
                                    </form>

                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php } ?>
             