<?php
/* ===== www.dedykuncoro.com ===== */
	include 'koneksi.php';
	
	class usr{}
	
	$tanggal = $_POST["tanggal"];
	$nis = $_POST["nis"];
		
	if ((empty($tanggal))) { 
		$response = new usr();
		$response->success = 0;
		$response->message = "Kolom tanggal tidak boleh kosong"; 
		die(json_encode($response));
	} else if ((empty($nis))) { 
		$response = new usr();
		$response->success = 0;
		$response->message = "Kolom nis tidak boleh kosong"; 
		die(json_encode($response));
	}  else {
		if (!empty($tanggal) && !empty($nis)){
			$ids = mysql_query("SELECT ids FROM siswa WHERE nis='".$nis."'");
			while ($data = mysql_fetch_array($ids)) {
				$idsdong = $data['ids'];
			}

			$ids2 = mysql_query("SELECT ids, tgl FROM absen WHERE ids='".$idsdong."'");
			while ($data2 = mysql_fetch_array($ids2)) {
				$idsdong2 = $data2['ids'];
				$idtgl = $data2['tgl'];
			}
			
			$num_rows = mysql_num_rows(mysql_query("SELECT * FROM absen WHERE tgl='".$tanggal."'"));
			$cek = mysql_num_rows(mysql_query("SELECT * FROM absen WHERE ids='".$idsdong."'"));


			if ($idsdong == $idsdong2 && $idtgl != $tanggal){
				$query = mysql_query("INSERT INTO absen (ids, tgl, ket, jam) VALUES('".$idsdong."','".$tanggal."','M','1')");
				if ($query){
					$response = new usr();
					$response->success = 1;
					$response->message = "Anda berhasil absen, selamat belajar :)";
					die(json_encode($response));

				} else {
					$response = new usr();
					$response->success = 0;
					$response->message = "Anda sudah absen";
					die(json_encode($response));
				}
			} else if ($idsdong != $idsdong2 && $idtgl != $tanggal){
				$query = mysql_query("INSERT INTO absen (ids, tgl, ket, jam) VALUES('".$idsdong."','".$tanggal."','M','1')");
				if ($query){
					$response = new usr();
					$response->success = 2;
					$response->message = "Anda berhasil absen, selamat belajar :)";
					die(json_encode($response));

				} else {
					$response = new usr();
					$response->success = 0;
					$response->message = "Anda sudah absen";
					die(json_encode($response));
				}
			}  else {
				$response = new usr();
				$response->success = 0;
				$response->message = "Anda sudah absen !";
				die(json_encode($response));
			}
		}
	}

	mysql_close();


	/* ========= KALAU PAKAI MYSQLI YANG ATAS SEMUA DI REMARK, TERUS YANG INI DI UNREMARK ======== */
	// include_once "koneksi.php";

	// class usr{}

	// $tanggal = $_POST["tanggal"];
	// $nis = $_POST["nis"];
	// $confirm_nis = $_POST["confirm_nis"];

	// if ((empty($tanggal))) {
	// 	$response = new usr();
	// 	$response->success = 0;
	// 	$response->message = "Kolom tanggal tidak boleh kosong";
	// 	die(json_encode($response));
	// } else if ((empty($nis))) {
	// 	$response = new usr();
	// 	$response->success = 0;
	// 	$response->message = "Kolom nis tidak boleh kosong";
	// 	die(json_encode($response));
	// } else if ((empty($confirm_nis)) || $nis != $confirm_nis) {
	// 	$response = new usr();
	// 	$response->success = 0;
	// 	$response->message = "Konfirmasi nis tidak sama";
	// 	die(json_encode($response));
	// } else {
		// if (!empty($tanggal) && $nis == $confirm_nis){
		// 	$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM users WHERE tanggal='".$tanggal."'"));

		// 	if ($num_rows == 0){
		// 		$query = mysqli_query($con, "INSERT INTO users (id, tanggal, nis) VALUES(0,'".$tanggal."','".$nis."')");

		// 		if ($query){
		// 			$response = new usr();
		// 			$response->success = 1;
		// 			$response->message = "Register berhasil, silahkan login.";
		// 			die(json_encode($response));

		// 		} else {
		// 			$response = new usr();
		// 			$response->success = 0;
		// 			$response->message = "tanggal sudah ada";
		// 			die(json_encode($response));
		// 		}
		// 	} else {
		// 		$response = new usr();
		// 		$response->success = 0;
		// 		$response->message = "tanggal sudah ada";
		// 		die(json_encode($response));
		// 	}
		// }
	// }

	// mysqli_close($con);

?>	