<?php 
	/* ===== www.dedykuncoro.com ===== */
	include_once "koneksi.php";

	$hari = $_POST['keyword'];
	$kelas = $_POST['kelas'];

	$query = mysqli_query($con, "SELECT * FROM jadwal WHERE hari ='$hari' AND kelas='$kelas'");

	$num_rows = mysqli_num_rows($query);



	if ($num_rows > 0){
		$json = '{"value":1, "results": [';

		while ($row = mysqli_fetch_array($query)){
			$char ='"';

			$json .= '{
				"id": "'.str_replace($char,'`',strip_tags($row['jam_ke'])).'",
				"nama": "'.str_replace($char,'`',strip_tags($row['mapel'])).'",
				"guru": "'.str_replace($char,'`',strip_tags($row['guru'])).'"
			},';
		}

		$json = substr($json,0,strlen($json)-1);

		$json .= ']}';

	} else {
		$json = '{"value":0, "message": "Data tidak ditemukan."}';
	}

	echo $json;

	mysqli_close($con);
?>