Debug
=====

.. doxygenfunction:: GSM_SetDebugFunction
.. doxygenfunction:: GSM_SetDebugFile
.. doxygenfunction:: GSM_SetDebugFileDescriptor
.. doxygenfunction:: GSM_GetGlobalDebug
.. doxygenfunction:: GSM_GetDebug
.. doxygenfunction:: GSM_GetDI
.. doxygenfunction:: GSM_SetDebugLevel
.. doxygenfunction:: GSM_SetDebugCoding
.. doxygenfunction:: GSM_SetDebugGlobal
.. doxygenfunction:: GSM_LogError
.. doxygenfunction:: smprintf
.. doxygentypedef:: GSM_Debug_Info
