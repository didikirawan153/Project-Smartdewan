INI files
=========

.. doxygenfunction:: INI_Free
.. doxygenfunction:: INI_ReadFile
.. doxygenfunction:: INI_FindLastSectionEntry
.. doxygenfunction:: INI_GetValue
.. doxygenfunction:: INI_GetInt
.. doxygenfunction:: INI_GetBool
.. doxygenfunction:: GSM_StringToBool

.. doxygentypedef:: INI_Entry
.. doxygentypedef:: INI_Section
.. doxygenstruct:: _INI_Entry
.. doxygenstruct:: _INI_Section
