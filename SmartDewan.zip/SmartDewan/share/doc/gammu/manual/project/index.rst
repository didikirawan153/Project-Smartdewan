.. _project:

Gammu project
=============

.. toctree::
    :maxdepth: 2

    about
    motivation
    install
    contributing
    localization
    testing
    coding-style
    versioning
    documentation
    directories
    roadmap
