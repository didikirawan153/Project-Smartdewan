Python-gammu FAQ
================

Where can I download python-gammu?
----------------------------------

The python-gammu project has been merged into `Gammu`_, so you just need
to grab `Gammu`_ and it includes python-gammu. Binaries for Windows are
distributed separately.

How can I use python-gammu?
---------------------------

There are lot of examples shipped with Gammu, you can find them in
python/examples subdirectory.

.. seealso:: :ref:`python`, :ref:`python-gammu-examples`

.. _Gammu: http://wammu.eu/gammu/
