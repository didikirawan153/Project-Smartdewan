-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2019 at 06:08 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `absen-siswa`
--
CREATE DATABASE IF NOT EXISTS `absen-siswa` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `absen-siswa`;

-- --------------------------------------------------------

--
-- Table structure for table `absen_siswa`
--

CREATE TABLE `absen_siswa` (
  `nis` int(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alasan` text NOT NULL,
  `dari_tanggal` varchar(10) NOT NULL,
  `sampai_tanggal` varchar(10) NOT NULL,
  `waktu_submit` time NOT NULL,
  `ais` varchar(10) NOT NULL COMMENT 'a=alpha,s=sakit,i=izin',
  `status` varchar(20) NOT NULL DEFAULT '0' COMMENT '1= TRUE, 0=FALSE',
  `kelas` varchar(200) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  `masuk` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `absen_siswa`
--

INSERT INTO `absen_siswa` (`nis`, `nama`, `alasan`, `dari_tanggal`, `sampai_tanggal`, `waktu_submit`, `ais`, `status`, `kelas`, `jurusan`, `masuk`) VALUES
(234234, 'Joviandor nopier marbun', 'Sakit keran', '2017-09-10', '2017-09-10', '19:58:36', 'i', '0', '12', 'RPL', '0'),
(332323, 'Saddil ramdani', 'Main bola', '2017-09-15', '2017-09-17', '20:33:28', 'i', '0', '12', 'TSM', '0'),
(3242343, 'Yiek alfian rifky ananda', 'azz mager', '2017-09-12', '2017-09-14', '20:15:55', 'a', '0', '12', 'RPL', '0'),
(3423432, 'Fahrizal ', 'Masuk angin', '2017-09-06', '2017-09-10', '20:42:27', 's', '0', '12', 'RPL', '0'),
(3432423, 'Kevin hendra wijaya', 'Nenek sakit demam', '2017-09-07', '2017-09-08', '10:55:37', 'i', '0', '12', 'RPL', '0'),
(21321312, 'Fadlawalad zo carli', 'zzzzz', '2017-09-11', '2017-09-15', '11:48:31', 's', '0', '12', 'RPL', '0');

-- --------------------------------------------------------

--
-- Table structure for table `data_login`
--

CREATE TABLE `data_login` (
  `id` int(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `posisi` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_login`
--

INSERT INTO `data_login` (`id`, `nama`, `password`, `posisi`) VALUES
(6, 'Joviandro nopier marbun', '3376db48b9ea2d61a65b7b40a8897e8a', 'm'),
(7, 'Fadlawalad dimas zo carli', '960eae42eb6adabf8751ec9460ae03f5', 'a'),
(8, 'Yiek alfian rifki ananda', '6545350732e410313f4c5c71fb553b98', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `data_siswa`
--

CREATE TABLE `data_siswa` (
  `nis` int(255) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `no_telp_ortu` int(15) NOT NULL,
  `kelas` varchar(5) NOT NULL,
  `tempat_lahir` varchar(15) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `golongan_dar` varchar(3) NOT NULL,
  `no_telp_siswa` int(15) NOT NULL,
  `jurusan` varchar(20) NOT NULL,
  `status_absen` varchar(20) NOT NULL DEFAULT 'masuk'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `data_siswa`
--

INSERT INTO `data_siswa` (`nis`, `nama_lengkap`, `alamat`, `no_telp_ortu`, `kelas`, `tempat_lahir`, `tgl_lahir`, `golongan_dar`, `no_telp_siswa`, `jurusan`, `status_absen`) VALUES
(234234, 'Joviandor nopier marbun', 'adsadsadsadJLAMD', 2444432, '12', 'Bogot', '2017-09-05', 'O', 24444333, 'RPL', 'tidak,verif'),
(332323, 'Saddil ramdani', 'asdsadsad', 24443, '12', 'Bogot', '2017-09-13', 'AB', 333322, 'TSM', 'tidak'),
(3242343, 'Yiek alfian rifky ananda', 'Jl.lengkong wetan', 2222, '12', 'jayapura', '2017-09-13', 'B', 999999, 'RPL', 'tidak'),
(3423432, 'Fahrizal ', 'asdsad', 34234, '12', 'sdfsdfdsfsd', '2017-09-12', 'O', 343543, 'RPL', 'tidak,verif'),
(3432423, 'Kevin hendra wijaya', 'asdasdsa', 21321, '12', 'Bogor', '2017-08-23', 'O', 432432, 'RPL', 'tidak,verif'),
(21321312, 'Fadlawalad zo carli', 'sadasdas', 2423432, '12', 'Tangerang ', '2017-08-10', 'A', 21321321, 'RPL', 'tidak,verif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absen_siswa`
--
ALTER TABLE `absen_siswa`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `data_login`
--
ALTER TABLE `data_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_siswa`
--
ALTER TABLE `data_siswa`
  ADD PRIMARY KEY (`nis`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_login`
--
ALTER TABLE `data_login`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;--
-- Database: `absensi_pkl`
--
CREATE DATABASE IF NOT EXISTS `absensi_pkl` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `absensi_pkl`;

-- --------------------------------------------------------

--
-- Table structure for table `bulan`
--

CREATE TABLE `bulan` (
  `id_bln` int(10) NOT NULL,
  `nama_bln` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bulan`
--

INSERT INTO `bulan` (`id_bln`, `nama_bln`) VALUES
(1, 'Januari'),
(2, 'Februari'),
(3, 'Maret'),
(4, 'April'),
(5, 'Mei'),
(6, 'Juni'),
(7, 'Juli'),
(8, 'Agustus'),
(9, 'September'),
(10, 'Oktober'),
(11, 'November'),
(12, 'Desember');

-- --------------------------------------------------------

--
-- Table structure for table `catatan`
--

CREATE TABLE `catatan` (
  `id_cat` int(10) NOT NULL,
  `id_user` int(10) NOT NULL,
  `id_bln` int(10) NOT NULL,
  `id_hri` int(10) NOT NULL,
  `id_tgl` int(10) NOT NULL,
  `isi_cat` longtext NOT NULL,
  `status_cat` enum('Menunggu','Dikonfirmasi','Ditolak') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `catatan`
--

INSERT INTO `catatan` (`id_cat`, `id_user`, `id_bln`, `id_hri`, `id_tgl`, `isi_cat`, `status_cat`) VALUES
(31, 2, 1, 4, 14, 'Fixed : Navbar link, bug absen pulang, empty input data', 'Dikonfirmasi'),
(32, 4, 1, 4, 14, 'Tes fixes bug empty note', 'Dikonfirmasi'),
(33, 4, 1, 4, 14, 'Tidak ada kegiatan, rencannya mau beresin kabel tapi wktunya ngga memungkinkan jadi di tunda.dikasih minum es kelapa muda. :D', 'Dikonfirmasi'),
(34, 4, 1, 5, 15, 'Identifikasi pc yg tidak bisa masuk bios, ternyata masalah di power supplynya. Setelah di ganti power supplynya baru bisa masuk bios kemudian di install ulang paki windows 7', 'Dikonfirmasi'),
(35, 4, 1, 5, 15, 'Identifikasi pc yg tidak bisa masuk bios, ternyata masalah di power supplynya. Setelah di ganti power supplynya baru bisa masuk bios kemudian di install ulang paki windows 7', 'Dikonfirmasi'),
(44, 3, 1, 7, 17, 'Semoga lebih baik :D', 'Menunggu'),
(43, 2, 1, 7, 17, 'Tes ya', 'Menunggu'),
(39, 4, 1, 7, 17, 'Mysqli fix bug real escape string', 'Dikonfirmasi'),
(40, 4, 1, 7, 17, 'Testing 2nd Migration to MySQLi', 'Menunggu'),
(41, 2, 1, 7, 17, 'Testing 2nd Migrations To MySQLi', 'Menunggu'),
(45, 4, 1, 2, 19, 'Senin bersihin Ram trus install ulang', ''),
(46, 5, 2, 5, 19, 'Hemmm tes aja deh :D Hahaha :*', 'Dikonfirmasi'),
(47, 3, 2, 5, 19, 'Terimakasih Untuk hari ini :D\\r\\nTerimakasih atas semua kebaikan ini :D', 'Menunggu'),
(48, 3, 2, 5, 19, 'Tes fix Bug :D\r\nSemangaaatt :D ''''" <- tesss', 'Menunggu');

-- --------------------------------------------------------

--
-- Table structure for table `data_absen`
--

CREATE TABLE `data_absen` (
  `id_absen` int(11) NOT NULL,
  `id_user` varchar(100) NOT NULL,
  `id_bln` int(10) NOT NULL,
  `id_hri` int(10) NOT NULL,
  `id_tgl` int(10) NOT NULL,
  `jam_msk` varchar(50) NOT NULL,
  `st_jam_msk` enum('Menunggu','Dikonfirmasi','Ditolak') NOT NULL,
  `jam_klr` varchar(50) NOT NULL,
  `st_jam_klr` enum('Belum Absen','Menunggu','Dikonfirmasi','Ditolak') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_absen`
--

INSERT INTO `data_absen` (`id_absen`, `id_user`, `id_bln`, `id_hri`, `id_tgl`, `jam_msk`, `st_jam_msk`, `jam_klr`, `st_jam_klr`) VALUES
(48, '4', 1, 5, 15, '12.58 WIB', 'Dikonfirmasi', '16.25 WIB', 'Dikonfirmasi'),
(49, '4', 1, 6, 16, '09.37 WIB', 'Dikonfirmasi', '', 'Belum Absen'),
(50, '2', 1, 6, 16, '15.41 WIB', 'Dikonfirmasi', '', 'Belum Absen'),
(51, '3', 1, 7, 17, '06.43 WIB', 'Ditolak', '', 'Belum Absen'),
(53, '4', 1, 7, 17, '18.00 WIB', 'Ditolak', '18.01 WIB', 'Ditolak'),
(54, '2', 1, 7, 17, '18.09 WIB', 'Ditolak', '18.09 WIB', 'Dikonfirmasi'),
(56, '4', 1, 1, 18, '07.16 WIB', 'Ditolak', '12.46 WIB', 'Dikonfirmasi'),
(58, '4', 1, 3, 20, '07.20 WIB', 'Ditolak', '07.20 WIB', 'Dikonfirmasi'),
(59, '4', 1, 4, 21, '07.14 WIB', 'Dikonfirmasi', '', 'Belum Absen'),
(60, '2', 1, 2, 26, '10.01 WIB', 'Dikonfirmasi', '10.01 WIB', 'Ditolak'),
(61, '2', 2, 3, 10, '16.58 WIB', 'Dikonfirmasi', '16.59 WIB', 'Menunggu'),
(66, '5', 4, 2, 9, '18.14 WIB', 'Menunggu', '', 'Belum Absen');

-- --------------------------------------------------------

--
-- Table structure for table `detail_pb`
--

CREATE TABLE `detail_pb` (
  `id_user` int(10) NOT NULL,
  `name_user` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_pb`
--

INSERT INTO `detail_pb` (`id_user`, `name_user`) VALUES
(3, 'Irfan'),
(8, 'Helmi'),
(1, 'Fauzi'),
(7, 'Haekal Nagib');

-- --------------------------------------------------------

--
-- Table structure for table `detail_user`
--

CREATE TABLE `detail_user` (
  `id_user` int(10) NOT NULL,
  `nis_user` int(25) NOT NULL,
  `name_user` varchar(255) NOT NULL,
  `sklh_user` varchar(255) NOT NULL,
  `jk_user` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_user`
--

INSERT INTO `detail_user` (`id_user`, `nis_user`, `name_user`, `sklh_user`, `jk_user`) VALUES
(4, 14151051, 'Maulana Rizal Hilman', 'SMK INFORMATIKA', 'L'),
(2, 9999999, 'Siswa', 'SISWA BERSISWA SISWA', 'L'),
(3, 1234567, 'Yasmin', 'SMK INFORMATIKA', 'P'),
(5, 232351, 'Entahlah Siapa', 'Dan Entah Dimana', 'L');

-- --------------------------------------------------------

--
-- Table structure for table `hari`
--

CREATE TABLE `hari` (
  `id_hri` int(10) NOT NULL,
  `nama_hri` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hari`
--

INSERT INTO `hari` (`id_hri`, `nama_hri`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jum''at'),
(6, 'Sabtu'),
(7, 'Minggu');

-- --------------------------------------------------------

--
-- Table structure for table `tanggal`
--

CREATE TABLE `tanggal` (
  `id_tgl` int(10) NOT NULL,
  `nama_tgl` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tanggal`
--

INSERT INTO `tanggal` (`id_tgl`, `nama_tgl`) VALUES
(1, '01'),
(2, '02'),
(3, '03'),
(4, '04'),
(5, '05'),
(6, '06'),
(7, '07'),
(8, '08'),
(9, '09'),
(10, '10'),
(11, '11'),
(12, '12'),
(13, '13'),
(14, '14'),
(15, '15'),
(16, '16'),
(17, '17'),
(18, '18'),
(19, '19'),
(20, '20'),
(21, '21'),
(22, '22'),
(23, '23'),
(24, '24'),
(25, '25'),
(26, '26'),
(27, '27'),
(28, '28'),
(29, '29'),
(30, '30'),
(31, '31');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL,
  `email_user` varchar(255) NOT NULL,
  `pwd_user` varchar(255) NOT NULL,
  `level_user` enum('sw','pb') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `email_user`, `pwd_user`, `level_user`) VALUES
(1, 'fauzi@gmail.com', 'b480c074d6b75947c02681f31c90c668c46bf6b8', 'pb'),
(5, 'entah@gmail.com', 'bfd59291e825b5f2bbf1eb76569f8fe7', 'sw'),
(4, 'rizal@gmail.com', '7c6d1abd196ae7d105998f689b9d17a259bcfa96', 'sw'),
(7, 'haekal@gmail.com', 'b480c074d6b75947c02681f31c90c668c46bf6b8', 'pb'),
(3, 'yasmuz@gmail.com', 'b480c074d6b75947c02681f31c90c668c46bf6b8', 'sw'),
(2, 'siswa@siswa.siswa', '7a24156a1971d85acf2ae64d9dbdf5322566636f', 'sw');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bulan`
--
ALTER TABLE `bulan`
  ADD PRIMARY KEY (`id_bln`);

--
-- Indexes for table `catatan`
--
ALTER TABLE `catatan`
  ADD PRIMARY KEY (`id_cat`);

--
-- Indexes for table `data_absen`
--
ALTER TABLE `data_absen`
  ADD PRIMARY KEY (`id_absen`);

--
-- Indexes for table `detail_pb`
--
ALTER TABLE `detail_pb`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `detail_user`
--
ALTER TABLE `detail_user`
  ADD PRIMARY KEY (`id_user`,`nis_user`);

--
-- Indexes for table `hari`
--
ALTER TABLE `hari`
  ADD PRIMARY KEY (`id_hri`);

--
-- Indexes for table `tanggal`
--
ALTER TABLE `tanggal`
  ADD PRIMARY KEY (`id_tgl`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`,`email_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bulan`
--
ALTER TABLE `bulan`
  MODIFY `id_bln` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `catatan`
--
ALTER TABLE `catatan`
  MODIFY `id_cat` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `data_absen`
--
ALTER TABLE `data_absen`
  MODIFY `id_absen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `hari`
--
ALTER TABLE `hari`
  MODIFY `id_hri` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tanggal`
--
ALTER TABLE `tanggal`
  MODIFY `id_tgl` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;--
-- Database: `db_android`
--
CREATE DATABASE IF NOT EXISTS `db_android` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_android`;

-- --------------------------------------------------------

--
-- Table structure for table `tb_pegawai`
--

CREATE TABLE `tb_pegawai` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `posisi` varchar(100) NOT NULL,
  `gajih` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pegawai`
--

INSERT INTO `tb_pegawai` (`id`, `nama`, `posisi`, `gajih`) VALUES
(1, 'Febri', 'Manager', '7000000'),
(2, 'Edi', 'PM', '4500000'),
(3, 'didik', 'we', '100000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;--
-- Database: `db_ujianonline`
--
CREATE DATABASE IF NOT EXISTS `db_ujianonline` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_ujianonline`;

-- --------------------------------------------------------

--
-- Table structure for table `modul`
--

CREATE TABLE `modul` (
  `id_modul` int(5) NOT NULL,
  `isi_modul` text NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modul`
--

INSERT INTO `modul` (`id_modul`, `isi_modul`, `gambar`) VALUES
(1, '<p>Halaman web yang Anda saksikan ini adalah sebuah aplikasi untuk \r\npengerjaan ujian secara online. Sistem ini hanya bisa diakses ketika \r\nAnda telah melakukan LOGIN. LOGIN ditandai dengan pengisian ID peserta \r\ndan password pada sebuah kotak login yang telah ditentukan. Ringkasnya \r\nhanya peserta yang telah terdaftar yang bisa mengikuti ujian online ini.</p>\r\n		<br><p>Jika Anda telah sukses dalam proses login, anda bisa mengisi \r\njawaban dalam setiap tes atau soal yang ada. Tapi jangan lupa baca \r\ndengan seksama beberapa peraturan yang harus Anda taati dan setujui \r\nsebelum pengerjaan soal. Pengerjaan soal-soal ujian online ini dibatasi \r\ndengan waktu ... Lho koq bisa. (Ya...bisa). Jadi Anda perhatikan dengan \r\nbaik soal-soal Anda, jawab dengan sejujurnya, dan jangan lupa perhatikan\r\n sisa waktu Anda mengerjakan. Kerjakan soal yang mudah-mudah lewati \r\nsoal-soal yang Anda anggap sulit. Karena soal yang sudah dikerjakan bisa\r\n dibenarkan atau diedit atau diulangi kembali, dengan catatan Anda masih\r\n punya sisa waktu yang cukup untuk mengerjakan.Jangan terburu-buru \r\nmengerjakannya, usahakan manfaatkan waktu Anda sebaik-baiknya.</p>\r\n		<br><p>Setelah Anda selesai mengerjakan.... Anda bisa melihat langsung\r\n jawaban Anda (Asyik donk ...). Yang jelas jangan berdebar-debar. Apapun\r\n hasilnya itulah kemampuan Anda. Oleh sebab itu bertindaklah yang jujur.</p>', 'kartun-computer.jpg'),
(2, '<!--[if gte mso 9]><xml>\r\n <w:WordDocument>\r\n  <w:View>Normal</w:View>\r\n  <w:Zoom>0</w:Zoom>\r\n  <w:TrackMoves/>\r\n  <w:TrackFormatting/>\r\n  <w:PunctuationKerning/>\r\n  <w:ValidateAgainstSchemas/>\r\n  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>\r\n  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>\r\n  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>\r\n  <w:DoNotPromoteQF/>\r\n  <w:LidThemeOther>IN</w:LidThemeOther>\r\n  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>\r\n  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>\r\n  <w:Compatibility>\r\n   <w:BreakWrappedTables/>\r\n   <w:SnapToGridInCell/>\r\n   <w:WrapTextWithPunct/>\r\n   <w:UseAsianBreakRules/>\r\n   <w:DontGrowAutofit/>\r\n   <w:SplitPgBreakAndParaMark/>\r\n   <w:DontVertAlignCellWithSp/>\r\n   <w:DontBreakConstrainedForcedTables/>\r\n   <w:DontVertAlignInTxbx/>\r\n   <w:Word11KerningPairs/>\r\n   <w:CachedColBalance/>\r\n  </w:Compatibility>\r\n  <m:mathPr>\r\n   <m:mathFont m:val="Cambria Math"/>\r\n   <m:brkBin m:val="before"/>\r\n   <m:brkBinSub m:val="--"/>\r\n   <m:smallFrac m:val="off"/>\r\n   <m:dispDef/>\r\n   <m:lMargin m:val="0"/>\r\n   <m:rMargin m:val="0"/>\r\n   <m:defJc m:val="centerGroup"/>\r\n   <m:wrapIndent m:val="1440"/>\r\n   <m:intLim m:val="subSup"/>\r\n   <m:naryLim m:val="undOvr"/>\r\n  </m:mathPr></w:WordDocument>\r\n</xml><![endif]--><!--[if gte mso 9]><xml>\r\n <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"\r\n  DefSemiHidden="true" DefQFormat="false" DefPriority="99"\r\n  LatentStyleCount="267">\r\n  <w:LsdException Locked="false" Priority="0" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Normal"/>\r\n  <w:LsdException Locked="false" Priority="9" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="heading 1"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 2"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 3"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 4"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 5"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 6"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 7"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 8"/>\r\n  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 9"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 1"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 2"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 3"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 4"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 5"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 6"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 7"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 8"/>\r\n  <w:LsdException Locked="false" Priority="39" Name="toc 9"/>\r\n  <w:LsdException Locked="false" Priority="35" QFormat="true" Name="caption"/>\r\n  <w:LsdException Locked="false" Priority="10" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Title"/>\r\n  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>\r\n  <w:LsdException Locked="false" Priority="11" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Subtitle"/>\r\n  <w:LsdException Locked="false" Priority="22" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Strong"/>\r\n  <w:LsdException Locked="false" Priority="20" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Emphasis"/>\r\n  <w:LsdException Locked="false" Priority="59" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Table Grid"/>\r\n  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text"/>\r\n  <w:LsdException Locked="false" Priority="1" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="No Spacing"/>\r\n  <w:LsdException Locked="false" Priority="60" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Shading"/>\r\n  <w:LsdException Locked="false" Priority="61" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light List"/>\r\n  <w:LsdException Locked="false" Priority="62" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Grid"/>\r\n  <w:LsdException Locked="false" Priority="63" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 1"/>\r\n  <w:LsdException Locked="false" Priority="64" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 2"/>\r\n  <w:LsdException Locked="false" Priority="65" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 1"/>\r\n  <w:LsdException Locked="false" Priority="66" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 2"/>\r\n  <w:LsdException Locked="false" Priority="67" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 1"/>\r\n  <w:LsdException Locked="false" Priority="68" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 2"/>\r\n  <w:LsdException Locked="false" Priority="69" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 3"/>\r\n  <w:LsdException Locked="false" Priority="70" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Dark List"/>\r\n  <w:LsdException Locked="false" Priority="71" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Shading"/>\r\n  <w:LsdException Locked="false" Priority="72" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful List"/>\r\n  <w:LsdException Locked="false" Priority="73" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Grid"/>\r\n  <w:LsdException Locked="false" Priority="60" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Shading Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="61" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light List Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="62" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Grid Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="63" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="64" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="65" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 1 Accent 1"/>\r\n  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision"/>\r\n  <w:LsdException Locked="false" Priority="34" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="List Paragraph"/>\r\n  <w:LsdException Locked="false" Priority="29" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Quote"/>\r\n  <w:LsdException Locked="false" Priority="30" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Intense Quote"/>\r\n  <w:LsdException Locked="false" Priority="66" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 2 Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="67" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="68" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="69" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="70" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Dark List Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="71" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Shading Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="72" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful List Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="73" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Grid Accent 1"/>\r\n  <w:LsdException Locked="false" Priority="60" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Shading Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="61" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light List Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="62" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Grid Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="63" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="64" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="65" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 1 Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="66" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 2 Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="67" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="68" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="69" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="70" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Dark List Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="71" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Shading Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="72" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful List Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="73" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Grid Accent 2"/>\r\n  <w:LsdException Locked="false" Priority="60" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Shading Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="61" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light List Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="62" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Grid Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="63" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="64" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="65" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 1 Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="66" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 2 Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="67" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="68" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="69" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="70" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Dark List Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="71" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Shading Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="72" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful List Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="73" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Grid Accent 3"/>\r\n  <w:LsdException Locked="false" Priority="60" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Shading Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="61" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light List Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="62" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Grid Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="63" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="64" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="65" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 1 Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="66" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 2 Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="67" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="68" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="69" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="70" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Dark List Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="71" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Shading Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="72" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful List Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="73" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Grid Accent 4"/>\r\n  <w:LsdException Locked="false" Priority="60" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Shading Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="61" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light List Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="62" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Grid Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="63" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="64" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="65" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 1 Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="66" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 2 Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="67" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="68" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="69" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="70" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Dark List Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="71" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Shading Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="72" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful List Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="73" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Grid Accent 5"/>\r\n  <w:LsdException Locked="false" Priority="60" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Shading Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="61" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light List Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="62" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Light Grid Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="63" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="64" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="65" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 1 Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="66" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium List 2 Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="67" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="68" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="69" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="70" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Dark List Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="71" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Shading Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="72" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful List Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="73" SemiHidden="false"\r\n   UnhideWhenUsed="false" Name="Colorful Grid Accent 6"/>\r\n  <w:LsdException Locked="false" Priority="19" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis"/>\r\n  <w:LsdException Locked="false" Priority="21" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis"/>\r\n  <w:LsdException Locked="false" Priority="31" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference"/>\r\n  <w:LsdException Locked="false" Priority="32" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Intense Reference"/>\r\n  <w:LsdException Locked="false" Priority="33" SemiHidden="false"\r\n   UnhideWhenUsed="false" QFormat="true" Name="Book Title"/>\r\n  <w:LsdException Locked="false" Priority="37" Name="Bibliography"/>\r\n  <w:LsdException Locked="false" Priority="39" QFormat="true" Name="TOC Heading"/>\r\n </w:LatentStyles>\r\n</xml><![endif]--><!--[if gte mso 10]>\r\n<style>\r\n /* Style Definitions */\r\n table.MsoNormalTable\r\n	{mso-style-name:"Table Normal";\r\n	mso-tstyle-rowband-size:0;\r\n	mso-tstyle-colband-size:0;\r\n	mso-style-noshow:yes;\r\n	mso-style-priority:99;\r\n	mso-style-qformat:yes;\r\n	mso-style-parent:"";\r\n	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;\r\n	mso-para-margin-top:0cm;\r\n	mso-para-margin-right:0cm;\r\n	mso-para-margin-bottom:10.0pt;\r\n	mso-para-margin-left:0cm;\r\n	line-height:115%;\r\n	mso-pagination:widow-orphan;\r\n	font-size:11.0pt;\r\n	font-family:"Calibri","sans-serif";\r\n	mso-ascii-font-family:Calibri;\r\n	mso-ascii-theme-font:minor-latin;\r\n	mso-fareast-font-family:"Times New Roman";\r\n	mso-fareast-theme-font:minor-fareast;\r\n	mso-hansi-font-family:Calibri;\r\n	mso-hansi-theme-font:minor-latin;\r\n	mso-bidi-font-family:"Times New Roman";\r\n	mso-bidi-theme-font:minor-bidi;}\r\n</style>\r\n<![endif]-->\r\n\r\n<h1 class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;text-align:\r\njustify;text-indent:1.0cm;line-height:200%" align="left"><span style="font-size:12.0pt;\r\nline-height:200%;font-family:" times="" new="" roman","serif""=""><font face="comic sans ms" size="3" color="#0000FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AKADEMI MANAJEMEN INFORMATIKA AMIK SELATPANKANG</font></span><span style="font-size:12.0pt;\r\nline-height:200%;font-family:" times="" new="" roman","serif""=""></span></h1><p class="MsoNormal" style="margin-bottom:12.0pt;text-align:center;\r\nline-height:normal" align="center"><b><span style="font-size:9.0pt;font-family:" verdana","sans-serif";="" mso-fareast-font-family:"times="" new="" roman";mso-bidi-font-family:"times="" roman";="" mso-fareast-language:in"="">Visi Perguruan Tinggi :</span></b><b><span style="font-size:9.0pt;mso-bidi-font-size:11.0pt;font-family:" verdana","sans-serif";="" mso-fareast-font-family:"times="" new="" roman";mso-bidi-font-family:"times="" roman";="" mso-fareast-language:in"="">&nbsp;</span></b><span style="font-size:9.0pt;\r\nfont-family:" verdana","sans-serif";mso-fareast-font-family:"times="" new="" roman";="" mso-bidi-font-family:"times="" roman";mso-fareast-language:in"=""></span><br><span style="font-size:9.0pt;\r\nfont-family:" verdana","sans-serif";mso-fareast-font-family:"times="" new="" roman";="" mso-bidi-font-family:"times="" roman";mso-fareast-language:in"="">\r\nMENCERDASKAN BANGSA DENGAN TEKNOLOGI INFORMASI</span><span style="font-size:\r\n9.0pt;mso-bidi-font-size:11.0pt;font-family:" verdana","sans-serif";mso-fareast-font-family:="" "times="" new="" roman";mso-bidi-font-family:"times="" roman";mso-fareast-language:="" in"="">&nbsp;</span><span style="font-size:9.0pt;font-family:" verdana","sans-serif";="" mso-fareast-font-family:"times="" new="" roman";mso-bidi-font-family:"times="" roman";="" mso-fareast-language:in"=""></span><br><span style="font-size:9.0pt;font-family:" verdana","sans-serif";="" mso-fareast-font-family:"times="" new="" roman";mso-bidi-font-family:"times="" roman";="" mso-fareast-language:in"=""></span><span style="font-size:9.0pt;font-family:" verdana","sans-serif";="" mso-fareast-font-family:"times="" new="" roman";mso-bidi-font-family:"times="" roman";="" mso-fareast-language:in"="">\r\n<br>\r\n<b>Misi Perguruan Tinggi :</b></span><b><span style="font-size:9.0pt;\r\nmso-bidi-font-size:11.0pt;font-family:" verdana","sans-serif";mso-fareast-font-family:="" "times="" new="" roman";mso-bidi-font-family:"times="" roman";mso-fareast-language:="" in"="">&nbsp;</span></b><span style="font-size:9.0pt;font-family:" verdana","sans-serif";="" mso-fareast-font-family:"times="" new="" roman";mso-bidi-font-family:"times="" roman";="" mso-fareast-language:in"=""><br>\r\nMenyelenggarakan pendidikan berbasis teknologi informasi Memberikan kesempatan\r\nbelajar dan beasiswa kepada yang berprestasi Memberdayakan dan meningkatkan\r\nsumber daya yang dimiliki Menciptakan atmosfir akademik yang sehat dan\r\nberwawasan Mengembangkan budaya akademik secara berkelanjutan Menghasilkan\r\nlulusan yang terampil dan mampu berkompetisi Melakukan penelitian dan\r\npengembangan dibidang teknologi informasi Menjalin kerjasama baik dengan\r\npemerintah maupun swasta sebagai mitra kerja.</span></p>\r\n\r\n<p>\r\n&nbsp;\r\n</p>\r\n<p>\r\n</p>\r\n', 'kampu amik.jpg'),
(3, '<ol><li>Bacalah dengan teliti tiap-tiap soal sebelum menjawab</li><li>Pengerjaan\r\n Soal-soal tes akan diberikan batasan waktu, apabila waktu telah \r\nhabis, anda tidak dapat lagi mengisi / mengoreksi kembali jawaban dari \r\nsoal-soal yang tersedia. Begitu pula sebaliknya apabila waktu yang \r\ntersedia masih ada maka anda dapat secara bebas mengoreksi kembali \r\njawaban-jawaban anda . <br></li><li>Skor atau nilai hanya akan ditampilkan saja tanpa adanya sertifikasi nilai untuk di download.</li></ol>', 'logo_sarolangun.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id_admin` int(3) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai`
--

CREATE TABLE `tbl_nilai` (
  `id_nilai` int(7) NOT NULL,
  `id_user` int(5) NOT NULL,
  `benar` varchar(20) NOT NULL,
  `salah` varchar(20) NOT NULL,
  `kosong` varchar(20) NOT NULL,
  `score` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengaturan_ujian`
--

CREATE TABLE `tbl_pengaturan_ujian` (
  `id` int(4) NOT NULL,
  `nama_ujian` varchar(20) NOT NULL,
  `waktu` varchar(20) NOT NULL,
  `nilai_min` varchar(20) NOT NULL,
  `peraturan` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengaturan_ujian`
--

INSERT INTO `tbl_pengaturan_ujian` (`id`, `nama_ujian`, `waktu`, `nilai_min`, `peraturan`) VALUES
(1, ' Tes Ujian', '120', '50', '<ol><li>Bacalah dengan teliti tiap-tiap soal sebelum menjawab</li><li>Pengerjaan Soal-soal ujian akan diberikan batasan waktu, apabila waktu telah habis, anda tidak dapat lagi mengisi / mengoreksi kembali jawaban dari soal-soal yang tersedia. Begitu pula sebaliknya apabila waktu yang tersedia masih ada maka anda dapat secara bebas mengoreksi kembali jawaban-jawaban anda . <br></li><li>Skor atau nilai hanya akan ditampilkan saja tanpa adanya sertifikasi nilai untuk di download.<br></li></ol>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_soal`
--

CREATE TABLE `tbl_soal` (
  `id_soal` int(5) NOT NULL,
  `soal` text NOT NULL,
  `a` varchar(30) NOT NULL,
  `b` varchar(30) NOT NULL,
  `c` varchar(30) NOT NULL,
  `d` varchar(30) NOT NULL,
  `knc_jawaban` varchar(30) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `aktif` enum('Y','N') NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_soal`
--

INSERT INTO `tbl_soal` (`id_soal`, `soal`, `a`, `b`, `c`, `d`, `knc_jawaban`, `gambar`, `tanggal`, `aktif`) VALUES
(1, 'Takdir Allah SWT yang pasti terjadi dan tidak dapat dirubah disebut takdir ....', 'Muallaq', 'Mubrom', 'Mutlaq', 'Muqoyyad', 'b', '', '0000-00-00', 'Y'),
(3, 'Peristiwa penyembelihan Nabi Ismail AS, merupakan asal mula perintah berkurban untuk umat islam setiap ....', '10 Syawal', '10 Dzulqodah', '10 Dzulhijjah', '10 Muharam', 'c', '', '0000-00-00', 'Y'),
(4, '<b>Perhatikan beberapa pernyataan berikut!</b><div><br></div><div>1. Hijrah karena perintah Allah</div><div>2. Bersama dengan kaum Anshor mendirikan mesjid</div><div>3. Kaum muslimin kehilangan rasa aman dari kaum kafir quraisy</div><div>4. Menepati perjanjian aqobah pertama</div><div><br></div><div>Dari pernyataan di atas yang merupakan terjadinya hijrah terdapat pada nomor ....</div><div><br></div>', '1 dan 2', '1 dan 3', '2 dan 3', '3 dan 4', 'b', '', '0000-00-00', 'Y'),
(5, 'Udara yang kita butuhkan untuk bernapas adalah udara yang&nbsp; â€¦.<br>', 'Kotor', 'Bersih', 'Berasap', 'Berdebu', 'b', '', '0000-00-00', 'Y'),
(6, 'Salah satu usaha mengurangi pencemaran udara adalah â€¦.<br>', 'Menanam pohon', 'Menggunakan transportasi umum', 'Membangun gedung tinggi', 'Memakai mobil pribadi', 'a', '', '0000-00-00', 'Y'),
(7, 'Kerja sama yang dilakukan dua negara dinamakan kerja sama ....<br>', 'Regional', 'Bilateral', 'Global', 'Nasional', 'b', '', '0000-00-00', 'Y'),
(8, 'Indonesia resmi diterima sebagai anggota PPB pada tanggal ....', '28 Mei 1990', '25 Juli 1985', '28 September 1950', '27 Juni 1947', 'c', '', '0000-00-00', 'Y'),
(9, 'Politik luar negeri indonesia yang bebas aktif dicetuskan oleh ....', 'Ir. Soekarno', 'Soeharto', 'Moh. Hatta', 'Muhammad Roem', 'c', '', '0000-00-00', 'Y'),
(10, 'Jika&nbsp; 20/25 = 4/n, maka nilai yang benar untuk n adalah....<br>', '2', '3', '4', '5', 'd', '', '0000-00-00', 'Y'),
(11, 'Bu Eka mempunyai persediaan 0,6 kg gula pasir. Ia membeli lagi gula pasir sebanyak 11/4 kg. Jika sebanyak 0,9 kg digunakan untuk acara arisan. Sisa gula pasir Bu Lisa sebanyak....<br>', '17/20', '18/20', '19/20', '1', 'c', '', '0000-00-00', 'Y'),
(12, 'Jarak kota Brebes ke Semarang diketahui 160 km. Jika jarak pada peta 4 cm, maka skala yang digunakan oleh peta tersebut adalah ....<br>', '1 : 4.000.000', '1 : 5.000.000', '1 : 6.000.000', '1 : 6.400.000', 'a', '', '0000-00-00', 'Y'),
(13, 'Gempa yang disebabkan oleh tabrakan antar lempeng bumi disebut ....<br>', 'Vulkanik', 'Tektonik', 'Tsunami', 'Bumi', 'c', '', '0000-00-00', 'Y'),
(14, 'Globalisasi berasal dari kata ....', 'Globe', 'Global', 'Glob', 'Globale', 'a', '', '0000-00-00', 'Y'),
(15, 'Organisasi di bawah naungan PBB bergerak di bidang kesehatan adalah â€¦<br>', 'FAO', 'UNESCO', 'UNICEF', 'WHO', 'd', '', '0000-00-00', 'Y'),
(16, 'Berikut ini adalah sumber energi listrik, kecuali ....', 'Baterai', 'Dynamo', 'Isolator', 'Generator', 'c', '', '0000-00-00', 'Y'),
(17, 'Peristiwa alam seperti di gambar berikut adalah ....', 'Gerhana matahari cincin', 'Gerhana bulan', 'Gerhana matahari', 'Gerhana bulan total', 'c', '19gerhana matahari.jpg', '2018-07-12', 'Y'),
(18, 'The tourists can change their money at the â€¦.<br>', 'Hotel', 'Money changer', 'City hall', 'Airport', 'b', '', '0000-00-00', 'Y'),
(19, 'This traditional dance is fromâ€¦.<br>', 'Central java', 'West java', 'Bali', 'Yogyakarta', 'b', '70tari jaipong.jpg', '2018-07-12', 'Y'),
(20, 'Dalam berpidato kita harus memilih bahasa yang santun dan komunikatif. Komunikatif artinya&nbsp; ....<br>', 'Bahasa resmi', 'Bahasa yang sering diucapkan', 'Bahasa yang dipelajari', 'Bahasa yang dipahami', 'd', '', '0000-00-00', 'Y'),
(21, 'Penggunaan tanda garis miring yang tepat pada nomor surat adalah ....<br>', 'Nomor.24.III/Kop/2018/', 'Nomor : 24/III/Kop/2018', 'Nomor.24/III/Kop/2018', 'Nomor.24/III/Kop.2018/', 'b', '', '0000-00-00', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` text NOT NULL,
  `tgl_lahir` varchar(30) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `agama` varchar(40) NOT NULL,
  `kwgn` varchar(40) NOT NULL,
  `nama_ayah` varchar(40) NOT NULL,
  `nama_ibu` varchar(40) NOT NULL,
  `pekerjaan_ayah` varchar(40) NOT NULL,
  `pekerjaan_ibu` varchar(40) NOT NULL,
  `sekolah_asal` varchar(50) NOT NULL,
  `telp` varchar(13) NOT NULL,
  `alamat` text NOT NULL,
  `statusaktif` enum('Y','N') NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `nama`, `tgl_lahir`, `jk`, `agama`, `kwgn`, `nama_ayah`, `nama_ibu`, `pekerjaan_ayah`, `pekerjaan_ibu`, `sekolah_asal`, `telp`, `alamat`, `statusaktif`) VALUES
(62, 'andez', '827ccb0eea8a706c4c34a16891f84e7b', 'andez', '1989-01-15', 'Laki-Laki', 'Islam', 'Indoensia', 'sadsad', 'asdsad', 'sadsad', 'asdasd', 'sadsad', '213213', 'sadsadsad', 'Y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `modul`
--
ALTER TABLE `modul`
  ADD PRIMARY KEY (`id_modul`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tbl_nilai`
--
ALTER TABLE `tbl_nilai`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `tbl_pengaturan_ujian`
--
ALTER TABLE `tbl_pengaturan_ujian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_soal`
--
ALTER TABLE `tbl_soal`
  ADD PRIMARY KEY (`id_soal`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `modul`
--
ALTER TABLE `modul`
  MODIFY `id_modul` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id_admin` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_nilai`
--
ALTER TABLE `tbl_nilai`
  MODIFY `id_nilai` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbl_pengaturan_ujian`
--
ALTER TABLE `tbl_pengaturan_ujian`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_soal`
--
ALTER TABLE `tbl_soal`
  MODIFY `id_soal` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;--
-- Database: `education`
--
CREATE DATABASE IF NOT EXISTS `education` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `education`;

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `attendence_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `standard_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `attendence_date` date NOT NULL,
  `attended` int(11) NOT NULL,
  `attendence_reason` varchar(100) CHARACTER SET utf8 NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`attendence_id`, `school_id`, `standard_id`, `student_id`, `attendence_date`, `attended`, `attendence_reason`, `on_date`) VALUES
(1, 7, 13, 7, '2016-04-15', 1, '', '2016-04-17 13:24:10'),
(2, 7, 13, 15, '2016-04-15', 1, '', '2016-04-17 13:24:10'),
(3, 7, 13, 8, '2016-04-15', 1, '', '2016-04-17 13:24:10'),
(4, 8, 8, 1, '2016-04-18', 1, '', '2016-04-18 06:04:27'),
(5, 8, 8, 2, '2016-04-18', 1, '', '2016-04-18 06:04:27'),
(6, 8, 8, 3, '2016-04-18', 0, 'not well', '2016-04-18 06:04:27'),
(7, 8, 9, 4, '2016-04-25', 1, '', '2016-04-24 06:35:00'),
(8, 8, 9, 20, '2016-04-25', 1, '', '2016-04-24 06:35:00'),
(9, 7, 13, 7, '2016-04-25', 1, '', '2016-04-24 07:57:43'),
(10, 7, 13, 8, '2016-04-25', 1, '', '2016-04-24 07:57:43'),
(11, 7, 13, 15, '2016-04-25', 0, 'not well', '2016-04-24 07:57:43'),
(12, 7, 14, 9, '2016-04-25', 1, '', '2016-04-24 07:58:02'),
(13, 7, 14, 13, '2016-04-25', 0, 'not good', '2016-04-24 07:58:02'),
(14, 7, 14, 16, '2016-04-25', 1, '', '2016-04-24 07:58:02'),
(21, 7, 13, 7, '2016-04-26', 1, '', '2016-04-24 08:29:47'),
(22, 7, 13, 8, '2016-04-26', 1, '', '2016-04-24 08:29:47'),
(23, 7, 13, 15, '2016-04-26', 0, 'not well', '2016-04-24 08:29:47');

-- --------------------------------------------------------

--
-- Table structure for table `demo_enquiry`
--

CREATE TABLE `demo_enquiry` (
  `demo_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8 NOT NULL,
  `subject` varchar(100) CHARACTER SET utf8 NOT NULL,
  `message` varchar(100) CHARACTER SET utf8 NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demo_enquiry`
--

INSERT INTO `demo_enquiry` (`demo_id`, `name`, `email`, `phone`, `subject`, `message`, `on_date`) VALUES
(1, 'nirav', 'test@gmail.com', '9825858585', 'test', 'test', '2016-04-30 14:02:52');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `event_title` varchar(100) CHARACTER SET utf8 NOT NULL,
  `event_description` longtext CHARACTER SET utf8 NOT NULL,
  `event_image` varchar(100) CHARACTER SET utf8 NOT NULL,
  `event_start` date NOT NULL,
  `event_end` date NOT NULL,
  `event_status` int(11) NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `school_id`, `event_title`, `event_description`, `event_image`, `event_start`, `event_end`, `event_status`, `on_date`) VALUES
(1, 7, 'Exam paper written seminar', 'we are organize on student exam paper writing seminar at our school and we organize all type of examination preparation of all of student.', '', '2016-04-15', '2016-04-30', 1, '2016-04-12 15:01:53'),
(2, 7, 'annual program', 'we organize in annual function in our school..participated student please come to one day before you come in the school.', '', '2016-04-13', '2016-04-13', 1, '2016-04-12 15:04:07'),
(4, 8, 'fairwell party', 'we organize annual function and fair well party for detained student . so please come to our school and attain all program.', '', '2016-04-20', '2016-04-21', 1, '2016-04-13 05:00:09'),
(5, 8, 'test', 'test event', '', '2016-04-20', '2016-04-23', 1, '2016-04-13 05:00:26'),
(6, 7, 'test', 'test event for school1', '', '2016-04-25', '2016-04-27', 1, '2016-04-13 05:03:03'),
(9, 7, 'vegetable event', '1test vegetable event for all student in sayona school', 'slider2.jpg', '2016-04-14', '2016-04-15', 1, '2016-04-23 08:23:19'),
(10, 7, 'test', 'test', '', '2016-04-25', '2016-04-28', 1, '2016-04-23 13:41:28'),
(11, 8, 'test today event', 'test today event', '', '2016-04-24', '2016-04-24', 1, '2016-04-24 11:32:03'),
(12, 8, 'test today  and tommoro', 'teoday and tomorrow', '', '2016-04-24', '2016-04-26', 1, '2016-04-24 11:38:37'),
(13, 7, 'Diwali Rangoli Festival', 'Date : 25/10/2016 Rangoli function at play area at 11:00 Am.', 'ic_logo.png', '2016-10-25', '2016-10-26', 1, '2016-10-20 13:18:14'),
(14, 7, 'Diwali Rangoli Festival  Woman', 'Date : 25/10/2016 Rangoli function at play area at 11:00 Am.', 'casva.png', '2016-10-25', '2016-10-26', 1, '2016-10-20 13:26:36');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `exam_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `exam_title` varchar(50) CHARACTER SET utf8 NOT NULL,
  `exam_note` varchar(100) CHARACTER SET utf8 NOT NULL,
  `exam_status` int(11) NOT NULL,
  `exam_standard` int(11) NOT NULL,
  `exam_date` date NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exam_id`, `school_id`, `exam_title`, `exam_note`, `exam_status`, `exam_standard`, `exam_date`, `on_date`) VALUES
(1, 8, 'monthaly test', 'monthaly test', 0, 9, '2016-01-12', '2016-04-15 06:13:37'),
(2, 8, 'english test', 'english test', 0, 8, '2016-04-13', '2016-04-15 06:16:14'),
(3, 7, 'monthaly test', 'we can held this exam on next month', 0, 13, '2016-05-12', '2016-04-15 06:22:40'),
(4, 7, 'math test', 'this test held on any time and any date because this is test exam in surprice test', 0, 3, '2016-12-12', '2016-04-15 06:24:38'),
(5, 7, 'test exam', 'test exam', 0, 3, '2016-04-23', '2016-04-15 06:30:46'),
(6, 7, 'first test', 'first test for h.k.g in sayona school.', 0, 14, '2012-02-12', '2016-04-15 08:23:58'),
(7, 7, 'second test', 'second test for h.k.g in sayona school', 0, 1, '2012-12-12', '2016-04-15 10:29:35');

-- --------------------------------------------------------

--
-- Table structure for table `exam_result`
--

CREATE TABLE `exam_result` (
  `exam_result_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject` varchar(100) CHARACTER SET utf8 NOT NULL,
  `mark_obtain` varchar(100) CHARACTER SET utf8 NOT NULL,
  `total_mark` varchar(100) CHARACTER SET utf8 NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_result`
--

INSERT INTO `exam_result` (`exam_result_id`, `exam_id`, `student_id`, `subject`, `mark_obtain`, `total_mark`, `on_date`) VALUES
(1, 6, 9, 'gujarati', '23', '50', '2016-04-15 09:21:06'),
(2, 6, 13, 'gujarati', '26', '50', '2016-04-15 09:22:32'),
(3, 6, 13, 'hindi', '27', '50', '2016-04-15 09:25:11'),
(10, 6, 9, 'hindi', '25', '50', '2016-04-15 09:46:29'),
(11, 2, 1, 'gujarati', '36', '50', '2016-04-15 10:31:10'),
(12, 2, 2, 'gujarati', '23', '50', '2016-04-15 10:31:23'),
(13, 2, 3, 'gujarati', '23', '50', '2016-04-15 10:31:56');

-- --------------------------------------------------------

--
-- Table structure for table `holiday`
--

CREATE TABLE `holiday` (
  `holiday_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `holiday_title` varchar(100) CHARACTER SET utf8 NOT NULL,
  `holiday_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `holiday`
--

INSERT INTO `holiday` (`holiday_id`, `school_id`, `holiday_title`, `holiday_date`) VALUES
(1, 8, 'gandhi jayanti', '2016-04-25'),
(2, 8, 'krismas day', '2016-06-16'),
(3, 8, 'test holiday', '2016-04-26'),
(4, 7, 'gandhi jayanti', '2016-04-25'),
(5, 7, 'monson start', '2016-06-30'),
(6, 7, 'mehta bhuvan', '2016-05-02'),
(7, 7, 'makar sankraanti', '2016-06-23'),
(8, 7, 'testing day', '2016-06-12'),
(9, 7, 'modiji birthday', '2016-05-25'),
(10, 8, 'test holiday', '2016-04-01'),
(11, 8, 'shitla satam', '2016-08-25');

-- --------------------------------------------------------

--
-- Table structure for table `notice_board`
--

CREATE TABLE `notice_board` (
  `notice_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `notice_description` longtext CHARACTER SET utf8 NOT NULL,
  `notice_type` varchar(100) CHARACTER SET utf8 NOT NULL,
  `notice_status` int(11) NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice_board`
--

INSERT INTO `notice_board` (`notice_id`, `school_id`, `notice_description`, `notice_type`, `notice_status`, `on_date`) VALUES
(1, 7, 'tomorrow 20-04-2016 is holiday because tomorrow is Gandhi jay anti.so please inform all student and all parent', 'holiday', 1, '2016-04-18 07:15:05'),
(2, 7, 'our school organize meting on 25-04-2016.\r\nso all parent must be prensent on that dat.\r\ntime: 12:10 am\r\ndate: 25-04-2016', 'meating', 1, '2016-04-18 07:16:39'),
(3, 7, 'please present all student to next sunday', 'other', 0, '2016-04-18 07:17:15'),
(4, 7, 'all student please verify your exam result in 25-04-2016 to 28-04-2016.', 'circular', 1, '2016-04-18 08:38:51'),
(5, 8, 'date: 25-04-2016 is holiday because that day is our school mainatin on server side and lab releted', 'holiday', 1, '2016-04-18 08:40:20'),
(7, 8, 'this is notice for only standard 10 student..plase present all standard student for next sunday itsw an surprice test held for any subject', 'other', 1, '2016-04-18 08:53:11'),
(8, 8, 'test other notice', 'other', 1, '2016-04-18 09:01:16');

-- --------------------------------------------------------

--
-- Table structure for table `school_detail`
--

CREATE TABLE `school_detail` (
  `school_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `school_address` varchar(100) CHARACTER SET utf8 NOT NULL,
  `school_state` varchar(100) CHARACTER SET utf8 NOT NULL,
  `school_city` varchar(100) CHARACTER SET utf8 NOT NULL,
  `school_postal_code` varchar(100) CHARACTER SET utf8 NOT NULL,
  `school_phone1` varchar(50) CHARACTER SET utf8 NOT NULL,
  `school_phone2` varchar(50) CHARACTER SET utf8 NOT NULL,
  `school_email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `school_fax` varchar(50) CHARACTER SET utf8 NOT NULL,
  `school_logo` varchar(50) CHARACTER SET utf8 NOT NULL,
  `school_person_name` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_detail`
--

INSERT INTO `school_detail` (`school_id`, `user_id`, `school_name`, `school_address`, `school_state`, `school_city`, `school_postal_code`, `school_phone1`, `school_phone2`, `school_email`, `school_fax`, `school_logo`, `school_person_name`) VALUES
(1, 7, 'sayona school', 'nr.st bus stand, sanala road, morbi', '', 'morbi', '', '9125896325', '9696589630', 'sayonaschoolmorbi@gmail.com', '', 'school.jpg', 'mahavis sinh'),
(4, 8, 'navyug vidhyalay', 'nr. chitrakut society, b/h st bus stand, morbi', '', 'morbi', '', '9615896320', '', 'navyugvidhyalay@yahoo.com', '', '14454012981436168479.jpg', 'ansoya ben');

-- --------------------------------------------------------

--
-- Table structure for table `school_student_chat`
--

CREATE TABLE `school_student_chat` (
  `chat_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `message` varchar(200) CHARACTER SET utf8 NOT NULL,
  `subject` varchar(100) CHARACTER SET utf8 NOT NULL,
  `reply` varchar(200) CHARACTER SET utf8 NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_student_chat`
--

INSERT INTO `school_student_chat` (`chat_id`, `student_id`, `school_id`, `message`, `subject`, `reply`, `on_date`) VALUES
(1, 5, 7, 'tomorrow is my birthday..so i celebrate my birthday in school..?', 'birthday', '', '2016-04-24 08:52:24'),
(2, 1, 8, 'hi this is my test message', 'test', '', '2016-04-24 08:54:48'),
(3, 6, 7, 'can we celabrate all event in next week..?', 'event week', '<p>yes we celebrate</p>', '2016-04-24 08:55:25'),
(5, 7, 7, 'i am not good today so i will not come to the school. please inform to my class teacher', 'not well today', '<p>okay, care your heath.</p>', '2016-04-24 09:20:01'),
(6, 9, 7, 'hi this is my firs birthday to celebrat in school..?', 'celebrate birthdat', '<p>okay you can celebrate your birthday in school</p>', '2016-04-25 09:24:38'),
(7, 20, 8, 'my school bus is not come to the time in morning can you help and solve my problem please...?', 'school bus', '<p>oky..your school bus will be come to the time to time on tomorrow.</p>', '2016-04-24 09:36:28'),
(8, 7, 7, 'exam time and date with subject name.', 'sir, final exam date?', '<p>Exam start Next Monday 9:30 To 11:00 Mathas paper.</p>', '2016-10-20 10:13:24'),
(9, 7, 7, 'my family plan to visit Singapore summer holiday.', 'summer holiday date.?', '<p>Summer holiday start Date : 02/02/2016 To 08/02/2016.</p>', '2016-10-20 10:17:34');

-- --------------------------------------------------------

--
-- Table structure for table `standard`
--

CREATE TABLE `standard` (
  `standard_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `standard_title` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `standard`
--

INSERT INTO `standard` (`standard_id`, `school_id`, `standard_title`) VALUES
(1, 7, '1'),
(2, 7, '2'),
(3, 7, '3'),
(4, 7, '4'),
(5, 7, '5'),
(6, 7, '6'),
(7, 7, '7'),
(8, 8, '8'),
(9, 8, '9'),
(10, 8, '10'),
(12, 8, '7'),
(13, 7, 'L.K.G'),
(14, 7, 'H.K.G'),
(15, 7, '8'),
(16, 7, '9'),
(17, 7, '10');

-- --------------------------------------------------------

--
-- Table structure for table `student_detail`
--

CREATE TABLE `student_detail` (
  `student_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `student_user_name` varchar(100) NOT NULL,
  `student_status` int(11) NOT NULL,
  `student_password` varchar(100) NOT NULL,
  `student_orgpassword` varchar(100) NOT NULL,
  `student_unique_no` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `student_birthdate` date NOT NULL,
  `student_roll_no` varchar(100) NOT NULL,
  `student_standard` int(11) NOT NULL,
  `student_address` varchar(100) NOT NULL,
  `student_city` varchar(100) NOT NULL,
  `student_phone` varchar(50) NOT NULL,
  `student_parent_phone` varchar(50) NOT NULL,
  `student_enr_no` varchar(50) NOT NULL,
  `student_email` varchar(50) NOT NULL,
  `student_photo` varchar(100) NOT NULL,
  `student_branch` varchar(100) NOT NULL,
  `student_semester` varchar(100) NOT NULL,
  `student_division` varchar(50) NOT NULL,
  `student_batch` varchar(50) NOT NULL,
  `gcm_code` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_detail`
--

INSERT INTO `student_detail` (`student_id`, `school_id`, `student_user_name`, `student_status`, `student_password`, `student_orgpassword`, `student_unique_no`, `student_name`, `student_birthdate`, `student_roll_no`, `student_standard`, `student_address`, `student_city`, `student_phone`, `student_parent_phone`, `student_enr_no`, `student_email`, `student_photo`, `student_branch`, `student_semester`, `student_division`, `student_batch`, `gcm_code`) VALUES
(1, 8, 'nirav', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160413_570e22dc364ac', 'nirav patel', '2016-04-21', '1', 8, 'b/h vardhman apartment, alap road, satadhar park-2, morbi', 'morbi', '9696569630', '9696963652', '1', 'patelnirav@gmail.com', '14454052651436169016.png', 'computer', '1', 'a', 'morning', ''),
(2, 8, 'jayesh', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160413_570e231a92a07', 'jayesh kotadiya', '2016-04-08', '2', 8, 'b/h vardhman apartment, alap road, satadhar park-2, morbi', 'morbi', '9696569630', '', '', '', '', '', '', '', '', ''),
(3, 8, 'subhash', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160413_570e2483ae0b8', 'subhash sanghani', '2016-04-19', '3', 8, 'nr. bypass road,  sanala road, morbi', 'morbi', '9659636541', '', '', '', '144540526514361690161.png', '', '', '', '', ''),
(4, 8, 'gautam', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160413_570e2516a1dd4', 'gautam chadasana', '2016-04-21', '1', 9, 'chitrkut society, morbi', 'morbi', '9612596320', '', '', '', '', '', '', '', '', ''),
(5, 7, 'jagruti', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160413_570e254bf19cf', 'jagruti patel', '2016-04-09', '1', 1, 'behind vardhman apartment, alap road, morbi', 'morbi', '9612596256', '9636987563', '1', 'pateljagruti@gmail.com', '144540526514361690162.png', 'gujarati', '1', 'b', 'afternoon', ''),
(6, 7, 'manish', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160414_570f1d9307be8', 'manish pandya', '2016-04-18', '2', 1, 'at-mahendra nagar, nr cng petrol pump, morbi-2', 'morbi', '9636859630', '', '', '', '14454038951436170152.jpg', '', '', '', '', ''),
(7, 7, 'daxa', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160414_570f20d29a9c4', 'Daxa Parmar', '2016-04-10', '1', 13, 'sanala road, nr bypass road, morbi', 'morbi', '9258965230', '9869635696', '1', 'daxaparmar@gmail.com', '', '', '', '', '', 'eTAX_MFw8Y0:APA91bGBWC6C6A5mF_JtjZ6Pa3Rn3qqIk0-_Zl5JYN4jxVBuw2d8BpCg2cxGqmhKLqbKwO0-zft8hV__CYTg3GYGehhsY9uqjjbKzP_UwzMSmrWN99biQ6coJBSPK4sUPx4bumwaYXP6'),
(8, 7, 'meet', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160414_570f215b1f619', 'meet khavadiya', '2016-04-27', '2', 13, 'mahendranagar, morbi-2', 'morbi', '9696569630', '', '', '', '', '', '', '', '', ''),
(9, 7, 'akash', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160414_570f21ef8dbcd', 'akash patel', '2016-04-20', '1', 14, 'sakta sanala, morbi', 'morbi', '9612596256', '9636585630', '1', 'akashpatel@gmail.com', '14454012981436168479.jpg', 'gujarati', '1', 'a', 'morning', ''),
(10, 7, 'amit', 0, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160414_570f4cf672f74', 'amit panara', '1991-04-11', '1', 7, 'morbi-tankara road, tankara', 'morbi', '6935698560', '', '', '', '', '', '', '', '', ''),
(11, 7, 'test', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160415_57106dcf00a4c', 'test', '1991-12-31', '1', 2, 'morbi', 'morbi', '9696569630', '9696963652', '12', 'test@gmail.com', '144540389514361701521.jpg', 'hindi', '1', 'b', 'morning', ''),
(12, 7, 'gautam1', 0, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160415_5710741574633', 'gautam chadasana', '1991-12-12', '1', 16, 'morbi', 'morbi', '9621526963', '', '', '', '', '', '', '', '', ''),
(13, 7, 'nitish', 0, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160415_5710a56e706c1', 'nitish kumar', '1963-12-12', '2', 14, 'ravapar road, nr managlam medical , morbi', 'morbi', '9636859630', '', '', '', '', '', '', '', '', ''),
(14, 7, 'reshma', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160415_5710b0a9bd560', 'reshma patel', '1991-11-01', '1', 3, 'morbi-sanala road, lajai', 'morbi', '9369632587', '', '', '', '', '', '', '', '', ''),
(15, 7, 'nilesh', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160417_571311053cda1', 'nilesh goladhra', '1996-12-12', '5', 13, 'morbi', 'morbi', '9536985696', '', '', '', '', '', '', '', '', ''),
(16, 7, 'hitesh', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160417_571311296d1e0', 'hitesh virja', '1963-12-10', '6', 14, 'morbi', 'morbi', '9536985696', '', '', '', '', '', '', '', '', ''),
(17, 8, 'jayesh1', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160418_5714a58c326dc', 'jayesh sutariya', '1996-10-01', '5', 8, 'morbi', 'morbi', '9636961485', '', '', '', '', '', '', '', '', ''),
(18, 8, 'mahesh', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160418_5714a87bd8f0f', 'mahesh sitapara', '1996-03-01', '4', 8, 'at- lajai ravpar villege, morbi', 'morbi', '9364785963', '', '', '', '', '', '', '', '', ''),
(20, 8, 'chintan', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160418_5714bde01663b', 'chitan patel', '1996-03-06', '5', 9, 'morbi', 'morbi', '6935698560', '', '', '', '', '', '', '', '', ''),
(21, 8, 'test1', 1, 'ede997b0caf2ec398110d79d9eba38bb', 'terminal', '20160418_5714c2bf77de5', 'tets1', '2016-09-06', '1', 10, 'ravapr road morbi', 'morbi', '9625696325', '8956962478', '1', 'test@gmail.com', '', 'hindi', '1', 'b', 'morning', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_growth`
--

CREATE TABLE `student_growth` (
  `growth_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `standard_id` int(11) NOT NULL,
  `month` varchar(100) NOT NULL,
  `growth` varchar(100) NOT NULL,
  `percentage` varchar(50) NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_growth`
--

INSERT INTO `student_growth` (`growth_id`, `student_id`, `standard_id`, `month`, `growth`, `percentage`, `on_date`) VALUES
(1, 10, 7, 'January', 'average', '40', '2016-04-23 08:41:34'),
(9, 9, 14, 'February', 'good', '60', '2016-04-23 08:41:41'),
(11, 6, 1, 'February', 'average', '40', '2016-04-23 08:41:44'),
(12, 4, 9, 'January', 'excellent', '80', '2016-04-23 08:41:47'),
(13, 18, 8, 'January', 'everage', '40', '2016-04-23 08:41:50'),
(14, 18, 8, 'February', 'everage', '40', '2016-04-23 08:41:54'),
(17, 2, 8, 'April', 'everage', '40', '2016-04-23 08:41:57'),
(18, 2, 8, 'March', 'good', '60', '2016-04-23 08:42:00'),
(19, 1, 8, 'April', 'good', '60', '2016-04-23 08:42:03'),
(20, 1, 8, 'February', 'everage', '40', '2016-04-23 08:42:06'),
(21, 3, 8, 'April', 'good', '60', '2016-04-23 08:42:09'),
(23, 5, 1, 'April', 'best', '80', '2016-10-15 09:08:53'),
(24, 7, 13, 'January', 'good', '60', '2016-04-23 08:42:15'),
(26, 5, 1, 'January', 'Good', '60', '2016-10-15 09:08:11'),
(28, 8, 13, 'January', 'average', '40', '2016-04-23 08:50:12'),
(29, 16, 14, 'January', 'Bad', '15', '2016-04-25 10:18:50'),
(31, 16, 14, 'February', 'Medium', '28', '2016-04-25 10:14:46'),
(32, 16, 14, 'April', 'Good', '65', '2016-04-25 10:15:15'),
(33, 16, 14, 'May', 'Excellent', '85', '2016-04-25 10:16:02'),
(35, 5, 1, 'February', 'Average', '65', '2016-10-15 09:08:34');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_detail`
--

CREATE TABLE `teacher_detail` (
  `teacher_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `teacher_name` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `maritalstatus` varchar(50) NOT NULL,
  `teacher_birthdate` date NOT NULL,
  `teacher_detail` longtext NOT NULL,
  `teacher_image` varchar(100) NOT NULL,
  `teacher_phone` varchar(50) NOT NULL,
  `teacher_email` varchar(50) NOT NULL,
  `teacher_education` varchar(100) NOT NULL,
  `teacher_address` varchar(100) NOT NULL,
  `teacher_exp` varchar(100) NOT NULL,
  `teacher_notes` varchar(100) NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_detail`
--

INSERT INTO `teacher_detail` (`teacher_id`, `school_id`, `teacher_name`, `gender`, `maritalstatus`, `teacher_birthdate`, `teacher_detail`, `teacher_image`, `teacher_phone`, `teacher_email`, `teacher_education`, `teacher_address`, `teacher_exp`, `teacher_notes`, `on_date`) VALUES
(1, 7, 'jagruti motka', 'female', 'single', '1991-04-09', '<p>standar : 8,9,10</p>\r\n\r\n<p>subject: gujarati, hindi and sanskrit..</p>\r\n\r\n<p>this is jagruti patel is good teacher for sanskrit and gujarati subject..she is special in extral all achivenent for our school</p>\r\n\r\n<p>&nbsp;</p>', '14454052651436169016.png', '9596254896', 'pateljagruti@gmail.com', 'M.A., B.ed', 'satadhar park-2, alap rasod, morbi', '2 year 6 month', 'paper taps in Gujarat board for Gujarati and Hindi subject', '2016-04-23 10:22:36'),
(2, 7, 'nirav patel', 'male', 'single', '1991-01-11', '<p>standard: 1 to 8</p>\r\n\r\n<p>subject : computer</p>\r\n\r\n<p>this is only one teacher in computer education he is very good knowledge of computer</p>', '14454012981436168479.jpg', '9692584596', '', 'bca,mca', 'sanala road, morbi', '1 year and 6 month', '', '2016-04-23 10:26:01'),
(3, 8, 'gautam ladani', 'male', 'married', '1990-11-01', '<p>standard: 1 to 6</p>\r\n\r\n<p>subject : gujarati</p>', '14454012981436168479.jpg', '9562587412', 'gautamladani@gmail.com', 'b.a', 'chitrakut society , morbi', '6 month', '', '2016-04-23 11:01:44'),
(4, 8, 'monika savani', 'female', 'married', '1998-09-15', '<p>standard: 11, 12 arts</p>\r\n\r\n<p>subject: english, social samaj</p>', '', '9632596858', '', 'M.A., B.ed', 'at- lajai, tankar road, morbi', '2 year 8 month', '', '2016-04-23 11:03:57'),
(6, 7, 'test1', 'female', 'married', '2016-02-21', '<p>test1</p>', '14454038951436170152.jpg', '96325968581', 'test1@gmail.com', 'ba, ma', 'morbi1', '1 year 6 month', 'extra1', '2016-04-23 12:23:21');

-- --------------------------------------------------------

--
-- Table structure for table `top_student`
--

CREATE TABLE `top_student` (
  `top_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `standard_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `student_rank` varchar(50) NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `top_student`
--

INSERT INTO `top_student` (`top_id`, `student_id`, `standard_id`, `school_id`, `student_rank`, `on_date`) VALUES
(22, 9, 14, 7, '3', '2016-05-02 04:19:27'),
(23, 13, 14, 7, '2', '2016-05-02 04:19:27'),
(24, 16, 14, 7, '1', '2016-05-02 04:19:27'),
(28, 7, 13, 7, '1', '2016-05-02 04:21:57'),
(29, 8, 13, 7, '3', '2016-05-02 04:21:57'),
(30, 15, 13, 7, '2', '2016-05-02 04:21:57'),
(35, 1, 8, 8, '3', '2016-05-02 04:23:16'),
(36, 2, 8, 8, '2', '2016-05-02 04:23:16'),
(37, 3, 8, 8, '1', '2016-05-02 04:23:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_type_access`
--

CREATE TABLE `user_type_access` (
  `user_type_id` int(11) NOT NULL,
  `class` varchar(30) NOT NULL,
  `method` varchar(30) NOT NULL,
  `access` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_type_access`
--

INSERT INTO `user_type_access` (`user_type_id`, `class`, `method`, `access`) VALUES
(0, 'admin', '*', 1),
(0, 'requestdemo', '*', 1),
(0, 'users', '*', 1),
(1, 'attendence', '*', 1),
(1, 'chat', '*', 1),
(1, 'event', '*', 1),
(1, 'exam', '*', 1),
(1, 'examresult', '*', 1),
(1, 'growth', '*', 1),
(1, 'holiday', '*', 1),
(1, 'noticeboard', '*', 1),
(1, 'school', '*', 1),
(1, 'standard', '*', 1),
(1, 'student', '*', 1),
(1, 'teacher', '*', 1),
(1, 'topstudent', '*', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE `user_types` (
  `user_type_id` int(11) NOT NULL,
  `user_type_title` varchar(30) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`user_type_id`, `user_type_title`) VALUES
(1, 'School');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `user_password` longtext NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `user_status` int(11) NOT NULL,
  `user_image` varchar(300) NOT NULL,
  `on_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_password`, `user_type_id`, `user_status`, `user_image`, `on_date`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 0, 1, 'women_gym_workout_wallpaper1.jpg', '2016-04-11 12:04:28'),
(7, 'school', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-04-11 12:04:28'),
(8, 'school of commerce', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-04-12 05:49:57'),
(9, 'school of arts', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-04-18 06:22:43'),
(10, 'school of computer', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-10-15 08:48:20'),
(11, 'school of pharmacy', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-10-15 08:49:03'),
(12, 'school of management', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-10-15 08:49:25'),
(13, 'school of engineering', '827ccb0eea8a706c4c34a16891f84e7b', 1, 1, '', '2016-10-15 08:50:31'),
(14, 'school of primary', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-10-15 08:51:11'),
(15, 'school  of higher secondary', 'ede997b0caf2ec398110d79d9eba38bb', 1, 1, '', '2016-10-15 08:52:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`attendence_id`),
  ADD UNIQUE KEY `standard_id` (`standard_id`,`student_id`,`attendence_date`);

--
-- Indexes for table `demo_enquiry`
--
ALTER TABLE `demo_enquiry`
  ADD PRIMARY KEY (`demo_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `exam_result`
--
ALTER TABLE `exam_result`
  ADD PRIMARY KEY (`exam_result_id`);

--
-- Indexes for table `holiday`
--
ALTER TABLE `holiday`
  ADD PRIMARY KEY (`holiday_id`);

--
-- Indexes for table `notice_board`
--
ALTER TABLE `notice_board`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `school_detail`
--
ALTER TABLE `school_detail`
  ADD PRIMARY KEY (`school_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `school_student_chat`
--
ALTER TABLE `school_student_chat`
  ADD PRIMARY KEY (`chat_id`);

--
-- Indexes for table `standard`
--
ALTER TABLE `standard`
  ADD PRIMARY KEY (`standard_id`);

--
-- Indexes for table `student_detail`
--
ALTER TABLE `student_detail`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `student_roll_no` (`student_roll_no`,`student_standard`),
  ADD UNIQUE KEY `student_roll_no_2` (`student_roll_no`,`student_standard`),
  ADD UNIQUE KEY `student_user_name` (`student_user_name`);

--
-- Indexes for table `student_growth`
--
ALTER TABLE `student_growth`
  ADD PRIMARY KEY (`growth_id`),
  ADD UNIQUE KEY `student_id` (`student_id`,`month`);

--
-- Indexes for table `teacher_detail`
--
ALTER TABLE `teacher_detail`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `top_student`
--
ALTER TABLE `top_student`
  ADD PRIMARY KEY (`top_id`),
  ADD UNIQUE KEY `student_id` (`student_id`,`standard_id`,`school_id`,`student_rank`);

--
-- Indexes for table `user_type_access`
--
ALTER TABLE `user_type_access`
  ADD UNIQUE KEY `user_type_id` (`user_type_id`,`class`,`method`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`user_type_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `attendence_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `demo_enquiry`
--
ALTER TABLE `demo_enquiry`
  MODIFY `demo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `exam_result`
--
ALTER TABLE `exam_result`
  MODIFY `exam_result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `holiday`
--
ALTER TABLE `holiday`
  MODIFY `holiday_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `notice_board`
--
ALTER TABLE `notice_board`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `school_detail`
--
ALTER TABLE `school_detail`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `school_student_chat`
--
ALTER TABLE `school_student_chat`
  MODIFY `chat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `standard`
--
ALTER TABLE `standard`
  MODIFY `standard_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `student_detail`
--
ALTER TABLE `student_detail`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `student_growth`
--
ALTER TABLE `student_growth`
  MODIFY `growth_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `teacher_detail`
--
ALTER TABLE `teacher_detail`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `top_student`
--
ALTER TABLE `top_student`
  MODIFY `top_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `user_types`
--
ALTER TABLE `user_types`
  MODIFY `user_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;--
-- Database: `hagihara`
--
CREATE DATABASE IF NOT EXISTS `hagihara` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hagihara`;

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `no_agt` int(5) NOT NULL,
  `nama_agt` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `divisi` varchar(30) NOT NULL,
  `nik` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`no_agt`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `no_agt` int(5) NOT NULL AUTO_INCREMENT;--
-- Database: `kuncoro_login`
--
CREATE DATABASE IF NOT EXISTS `kuncoro_login` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kuncoro_login`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'dedy', '123456'),
(9, 'ismi', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;--
-- Database: `perpus`
--
CREATE DATABASE IF NOT EXISTS `perpus` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `perpus`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(5) NOT NULL,
  `nama_admin` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `username`, `password`) VALUES
(1, 'Nawawi', 'admin', '81dc9bdb52d04dc20036dbd8313ed055'),
(2, 'Imam Nawawi', 'imam', '200ceb26807d6bf99fd6f4f0d1ca54d4'),
(4, 'admin', 'admin', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `id_anggota` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama_anggota` varchar(45) NOT NULL,
  `gender` enum('Laki-Laki','Perempuan') NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id_anggota`, `username`, `nama_anggota`, `gender`, `no_telp`, `alamat`, `email`, `password`) VALUES
(1, '', 'Irfan Maulanau', 'Laki-Laki', '02144445566', 'BSD', 'irfan@gmail.com', '123'),
(2, '', 'Nur Kumalasari', 'Perempuan', '02133335555', 'Ciledug', 'nur@gmail.com', '123'),
(3, '', 'Sanjaya Wijaya', 'Laki-Laki', '02111115555', 'Cimone', 'sanjaya@gmail.com', '123'),
(4, '', 'Eva Irfianingsih', 'Perempuan', '02166665555', 'Tangerang', 'eva@gmail.com', '123'),
(5, '', 'Ifqoh Permatasari', 'Perempuan', '02177775555', 'Cengkareng', 'ifqoh@gmail.com', '123'),
(6, '', 'Indah Riana', 'Perempuan', '02188885555', 'Fatmawati', 'indah@gmail.com', '123'),
(7, '', 'Tiwie Andrawati', 'Perempuan', '02199995555', 'Warung Jati', 'tiwie@gmail.com', '123'),
(11, 'imam', 'Imam Nawawi', 'Laki-Laki', '087829398630', 'jl H Isa no 1 Rengas Ciputat Timur', 'imam.imw@bsi.ac.id', '01cfcd4f6b8770febfb40cb906715822'),
(9, '', 'Hisbu Utomo', 'Laki-Laki', '02133336666', 'Salemba', 'hisbu@gmail.com', '123'),
(10, '', 'Zaenal Abidin', 'Laki-Laki', '02133337777', 'Bekasi', 'Zaenal@gmail.com', '123'),
(12, 'maruloh', 'Maruloh', 'Laki-Laki', '081519940383', 'Pedongkelan', 'maruloh.mru@gmail.com', '8d57dfe7398336d6b9164b4d62b6b42b'),
(13, '', 'dddd', 'Laki-Laki', '08888', '3333', 'jafarshodiq0412@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(5) NOT NULL,
  `id_kategori` int(5) NOT NULL,
  `judul_buku` varchar(50) NOT NULL,
  `pengarang` varchar(35) NOT NULL,
  `thn_terbit` date NOT NULL,
  `penerbit` varchar(50) NOT NULL,
  `isbn` varchar(25) NOT NULL,
  `jumlah_buku` int(3) NOT NULL,
  `lokasi` enum('Rak 1','Rak 2','Rak 3') NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `tgl_input` date NOT NULL,
  `status_buku` enum('1','0') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `id_kategori`, `judul_buku`, `pengarang`, `thn_terbit`, `penerbit`, `isbn`, `jumlah_buku`, `lokasi`, `gambar`, `tgl_input`, `status_buku`) VALUES
(2, 3, 'Mahir Pemrograman Web Dengan PHP', 'Adri Kusuma Wardana', '2014-03-18', 'Elex Media', '65412345', 2, 'Rak 3', 'gambar1539746444.jpg', '2018-07-24', '1'),
(3, 2, 'Mahir  Berhitung dan Mahir Mewarnai', 'Akhmad Rahmat', '2014-03-03', 'CV.Indo Kreasi', '7623447342', 4, 'Rak 3', 'gambar1539746653.jpg', '2018-07-25', '0'),
(4, 1, 'Dasar Dasar Fisika', 'Kurnia Sandi', '2013-04-04', 'Wacana Ria', '233214414', 3, 'Rak 2', 'gambar1539746772.jpg', '2018-07-24', '0'),
(5, 8, 'Mahir Bahasa Inggris', 'Aliuddin', '2013-05-05', 'CV.Indo Kreasi', '3553234454', 7, 'Rak 1', 'gambar1539746902.jpg', '2018-10-17', '1'),
(6, 4, 'Public Speaking', 'Pambudi Prasetyo', '2015-06-06', 'Aldi Pustaka', '843594759', 8, 'Rak 2', 'gambar1539747050.jpg', '2019-01-24', '0'),
(7, 3, 'Trik SQL', 'Ahdim Makaren', '2014-07-07', 'Wacana Ria', '54234762', 5, 'Rak 1', 'gambar1539747068.jpg', '2018-03-14', '1'),
(8, 6, 'Kemurnian Agama', 'Pambudi Prasetyo', '2014-08-08', 'Aldi Pustaka', '980958607', 3, 'Rak 3', 'gambar1539747079.jpg', '2018-07-24', '1'),
(9, 1, 'Mikrokontroler', 'Ahdim Makaren', '2012-09-09', 'Wacana Ria', '12121314', 11, 'Rak 2', 'gambar1539747096.jpg', '2018-04-11', '1'),
(10, 1, '24 Jam Belajar FrameWork', 'Rudi Hartono', '2017-03-02', 'Unjung Pena', '12345345', 10, 'Rak 2', 'gambar1539747110.jpg', '2018-05-08', '1'),
(11, 2, 'JavaScript uncover', 'Andre Pratama', '2015-03-12', 'Duniailkom', '9087654', 7, 'Rak 1', 'gambar1539747128.jpg', '2018-07-24', '1'),
(12, 3, 'Pemrograman dan Hack Android untuk pemula dan adva', 'Edy Winarno ST, M.eng, Ali Zaki, Sm', '2016-09-23', 'Elex Media Komputindo', '4234252', 7, 'Rak 1', 'gambar1539747149.jpg', '2018-07-25', '1'),
(16, 3, 'VB .Net', 'Azka', '2018-10-01', 'Elex Media', '12345678', 8, 'Rak 1', 'gambar1539747329.png', '2018-10-17', '1');

-- --------------------------------------------------------

--
-- Table structure for table `detail_pinjam`
--

CREATE TABLE `detail_pinjam` (
  `id_pinjam` varchar(5) NOT NULL,
  `id_buku` int(5) NOT NULL,
  `denda` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_pinjam`
--

INSERT INTO `detail_pinjam` (`id_pinjam`, `id_buku`, `denda`) VALUES
('PJ001', 16, 10000),
('PJ001', 6, 10000),
('PJ002', 2, 10000),
('PJ002', 1, 10000),
('PJ002', 4, 10000),
('PJ002', 3, 10000),
('PJ002', 8, 10000),
('PJ003', 1, 10000),
('PJ003', 2, 10000),
('PJ003', 3, 10000),
('PJ004', 1, 10000),
('PJ004', 2, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(5) NOT NULL,
  `nama_kategori` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Sains'),
(2, 'Hobby'),
(3, 'Komputer'),
(4, 'Komunikasi'),
(5, 'Hukum'),
(6, 'Agama'),
(7, 'Populer'),
(8, 'Bahasa'),
(9, 'komik');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_pinjam` varchar(5) NOT NULL,
  `tanggal_input` datetime NOT NULL,
  `id_anggota` int(5) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `tgl_pengembalian` date NOT NULL,
  `totaldenda` double NOT NULL DEFAULT '0',
  `status_peminjaman` enum('Booking','Selesai','Belum Selesai') DEFAULT 'Belum Selesai',
  `status_pengembalian` enum('Kembali','Belum Kembali') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`id_pinjam`, `tanggal_input`, `id_anggota`, `tgl_pinjam`, `tgl_kembali`, `tgl_pengembalian`, `totaldenda`, `status_peminjaman`, `status_pengembalian`) VALUES
('PJ001', '2019-01-24 12:01:33', 11, '2019-01-24', '2019-01-30', '2019-01-31', 0, 'Selesai', 'Kembali'),
('PJ002', '2019-04-23 20:04:12', 12, '0000-00-00', '0000-00-00', '0000-00-00', 0, 'Booking', ''),
('PJ003', '2019-04-23 20:04:42', 12, '0000-00-00', '0000-00-00', '0000-00-00', 0, 'Booking', ''),
('PJ004', '2019-04-23 20:04:07', 12, '0000-00-00', '0000-00-00', '0000-00-00', 0, 'Booking', '');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_pinjam` varchar(5) NOT NULL,
  `tgl_pencatatan` datetime NOT NULL,
  `id_anggota` int(4) NOT NULL,
  `id_buku` int(4) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `denda` double NOT NULL,
  `tgl_pengembalian` date NOT NULL,
  `total_denda` double NOT NULL,
  `status_pengembalian` varchar(15) NOT NULL,
  `status_peminjaman` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_pinjam`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD KEY `id_pinjam` (`id_pinjam`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id_anggota` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

--
-- Dumping data for table `pma__export_templates`
--

INSERT INTO `pma__export_templates` (`id`, `username`, `export_type`, `template_name`, `template_data`) VALUES
(1, 'root', 'server', 'dbsekolah', '{"quick_or_custom":"quick","what":"sql","db_select[]":["absen-siswa","absensi_pkl","db_android","db_ujianonline","education","hagihara","kuncoro_login","perpus","phpmyadmin","replas","sekolahku","tbl_user","test","user","volley_upload"],"output_format":"sendit","filename_template":"@SERVER@","remember_template":"on","charset":"utf-8","compression":"none","maxsize":"","codegen_structure_or_data":"data","codegen_format":"0","csv_separator":",","csv_enclosed":"\\"","csv_escaped":"\\"","csv_terminated":"AUTO","csv_null":"NULL","csv_structure_or_data":"data","excel_null":"NULL","excel_edition":"win","excel_structure_or_data":"data","htmlword_structure_or_data":"structure_and_data","htmlword_null":"NULL","json_structure_or_data":"data","latex_caption":"something","latex_structure_or_data":"structure_and_data","latex_structure_caption":"Structure of table @TABLE@","latex_structure_continued_caption":"Structure of table @TABLE@ (continued)","latex_structure_label":"tab:@TABLE@-structure","latex_relation":"something","latex_comments":"something","latex_mime":"something","latex_columns":"something","latex_data_caption":"Content of table @TABLE@","latex_data_continued_caption":"Content of table @TABLE@ (continued)","latex_data_label":"tab:@TABLE@-data","latex_null":"\\\\textit{NULL}","mediawiki_structure_or_data":"data","mediawiki_caption":"something","mediawiki_headers":"something","ods_null":"NULL","ods_structure_or_data":"data","odt_structure_or_data":"structure_and_data","odt_relation":"something","odt_comments":"something","odt_mime":"something","odt_columns":"something","odt_null":"NULL","pdf_report_title":"","pdf_structure_or_data":"data","phparray_structure_or_data":"data","sql_include_comments":"something","sql_header_comment":"","sql_compatibility":"NONE","sql_structure_or_data":"structure_and_data","sql_create_table":"something","sql_auto_increment":"something","sql_create_view":"something","sql_procedure_function":"something","sql_create_trigger":"something","sql_backquotes":"something","sql_type":"INSERT","sql_insert_syntax":"both","sql_max_query_size":"50000","sql_hex_for_binary":"something","sql_utc_time":"something","texytext_structure_or_data":"structure_and_data","texytext_null":"NULL","yaml_structure_or_data":"data","":null,"as_separate_files":null,"csv_removeCRLF":null,"csv_columns":null,"excel_removeCRLF":null,"excel_columns":null,"htmlword_columns":null,"json_pretty_print":null,"ods_columns":null,"sql_dates":null,"sql_relation":null,"sql_mime":null,"sql_use_transaction":null,"sql_disable_fk":null,"sql_views_as_tables":null,"sql_metadata":null,"sql_drop_database":null,"sql_drop_table":null,"sql_if_not_exists":null,"sql_truncate":null,"sql_delayed":null,"sql_ignore":null,"texytext_columns":null}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{"db":"sekolahku","table":"sekolah"},{"db":"sekolahku","table":"kelas"},{"db":"sekolahku","table":"jadwal"},{"db":"sekolahku","table":"pelajaran"},{"db":"user","table":"users"},{"db":"sekolahku","table":"siswa"},{"db":"replas","table":"detail"},{"db":"replas","table":"pengunjung"},{"db":"replas","table":"warga_binaan"},{"db":"db_android","table":"tb_pegawai"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2019-04-08 02:47:16', '{"collation_connection":"utf8mb4_general_ci"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;--
-- Database: `replas`
--
CREATE DATABASE IF NOT EXISTS `replas` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `replas`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(20) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `level`) VALUES
(1, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE `detail` (
  `id_detail` int(11) NOT NULL,
  `nama_peserta` varchar(30) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `waktu` varchar(10) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `blok_kamar` varchar(20) NOT NULL,
  `id_pengunjung` varchar(20) NOT NULL,
  `id_napi` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`id_detail`, `nama_peserta`, `tanggal`, `waktu`, `nama_barang`, `jumlah_barang`, `blok_kamar`, `id_pengunjung`, `id_napi`) VALUES
(1, 'yayukya', '20', '20', 'yyy', 3, 'D LT 1 D 5.2', '255', '2147483647'),
(4, 'Fiqih Hidayatullah', '30', '20', 'pakaian', 5, '', '32132101940001', '234567');

-- --------------------------------------------------------

--
-- Table structure for table `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengumuman`
--

INSERT INTO `pengumuman` (`id`, `status`) VALUES
(2, 'dihidupkan');

-- --------------------------------------------------------

--
-- Table structure for table `pengunjung`
--

CREATE TABLE `pengunjung` (
  `no_id` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `jenis_kelamin` varchar(12) NOT NULL,
  `agama` varchar(12) NOT NULL,
  `alamat` varchar(35) NOT NULL,
  `no_hp` varchar(12) NOT NULL,
  `ktp` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengunjung`
--

INSERT INTO `pengunjung` (`no_id`, `username`, `nama_lengkap`, `password`, `jenis_kelamin`, `agama`, `alamat`, `no_hp`, `ktp`) VALUES
('0', 'didik irawan', '', 'hpm123456', 'lelaki', 'islam', 'gempolan', '', ''),
('1', 'boncu', 'kerjo', '12345', 'ahmad', '+62815096821', 'islam', 'wanita', ''),
('123456', 'bocukkk', 'subang', '12345', 'fikih ahhh', '+62815096821', 'hindu', 'cewe', 'http://192.168.100.36/replas/images/ktp/.png'),
('255', 'yayuk', 'yayukya', '6666', 'cewe', 'islam', 'yyyyy', '+62815096821', 'http://192.168.100.36/replas/images/ktp/qzjdsh8rayebwh5repvy.png'),
('258', 'iqbale', 'iqbal sahrisal', '2009', 'cewe', 'gatau', 'jauh', '+62815096821', 'http://192.168.100.36/replas/images/ktp/ams810hkw2huy64fin0n.png'),
('2653', 'dahlan', 'dahlan irawan', '54321', 'cowo', 'islam', 'jauh', '+62815096821', 'http://192.168.100.36/replas/images/ktp/.png'),
('3213092101940002', 'rani', 'Siti Nur Rani', '456', 'Perempuan', 'Islam', '      Indramayu', '081809682121', 'Abstract-Fringe-Wallpapers-HD-Download-77829_NVT3B7I.jpg'),
('32132101940001', 'Fiqih', 'Fiqih Hidayatullah', '123', 'Laki-Laki', 'Islam', '      Subang', '081829682211', 'MyAvatar.png'),
('3216549870', 'fitri', 'fitri febriyanti', '123456', 'laki - laki', 'islam', 'subang', '081809682112', 'http://192.168.100.36/replas/images/ktp/thz3pa3sxx52skxmt63r.png'),
('5555', 'candra', 'candra aja', '123456', 'bencong', 'hindu', 'jauh kaki', '+62815096821', 'http://192.168.100.36/replas/images/ktp/e3bukxmitvexzftip2ya.png');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `nope` int(12) NOT NULL,
  `judul` varchar(20) NOT NULL,
  `isi` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `warga_binaan`
--

CREATE TABLE `warga_binaan` (
  `id_warbin` int(20) NOT NULL,
  `lokasi_sel` varchar(20) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `nama_panggilan` varchar(10) NOT NULL,
  `nama_ayah` varchar(20) NOT NULL,
  `jenis_kelamin` varchar(12) NOT NULL,
  `agama` varchar(12) NOT NULL,
  `kewarganegaraan` varchar(20) NOT NULL,
  `tempat_lahir` varchar(20) NOT NULL,
  `tanggal_lahir` varchar(20) NOT NULL,
  `tanggal_masuk` varchar(20) NOT NULL,
  `tanggal_ekspirasi` varchar(20) NOT NULL,
  `alamat` varchar(60) NOT NULL,
  `perkara` varchar(50) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `no_registrasi` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `warga_binaan`
--

INSERT INTO `warga_binaan` (`id_warbin`, `lokasi_sel`, `nama_lengkap`, `nama_panggilan`, `nama_ayah`, `jenis_kelamin`, `agama`, `kewarganegaraan`, `tempat_lahir`, `tanggal_lahir`, `tanggal_masuk`, `tanggal_ekspirasi`, `alamat`, `perkara`, `foto`, `no_registrasi`, `status`) VALUES
(12345, '', 'boncu fikih', '', '', '', '', '', '', '0000-00-00', '0000-00-00', '0000-00-00', '', '', '', '', ''),
(234567, '', 'boncu fikih', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2147483647, 'D LT 1 D 5.2', 'A SOPANDI', 'WAKIL', 'MAMAT RAHMAT', 'Laki-laki', 'Islam', 'Indonesia', 'Karawang', '1980-03-11', '1980-03-11', '1980-03-11', 'Karawang', 'Kejahatan', '', 'BI.103/18 N', 'Narapidana');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`id_detail`);

--
-- Indexes for table `pengunjung`
--
ALTER TABLE `pengunjung`
  ADD PRIMARY KEY (`no_id`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warga_binaan`
--
ALTER TABLE `warga_binaan`
  ADD PRIMARY KEY (`id_warbin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `detail`
--
ALTER TABLE `detail`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;--
-- Database: `sekolahku`
--
CREATE DATABASE IF NOT EXISTS `sekolahku` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sekolahku`;

-- --------------------------------------------------------

--
-- Table structure for table `absen`
--

CREATE TABLE `absen` (
  `ida` int(10) NOT NULL,
  `ids` varchar(10) NOT NULL,
  `tgl` varchar(100) NOT NULL,
  `ket` varchar(3) NOT NULL,
  `jam` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `absen`
--

INSERT INTO `absen` (`ida`, `ids`, `tgl`, `ket`, `jam`) VALUES
(97, '5', '16-4-2019', 'M', 1),
(98, '5', '15-4-2019', 'M', 1),
(99, '1', '15-4-2019', 'M', 1),
(100, '1', '15-4-2019', 'M', 1),
(101, '1', '15-4-2019', 'M', 1),
(102, '1', '14-4-2019', 'M', 1),
(103, '13', '14-4-2019', 'M', 1),
(104, '14', '14-4-2019', 'M', 1),
(105, '14', '15-4-2019', 'M', 1),
(106, '14', '16-4-2019', 'M', 1),
(107, '15', '16-4-2019', 'M', 1),
(108, '1', '17-4-2019', 'M', 1),
(109, '46', '14-4-2019', 'M', 1),
(110, '1', '19-4-2019', 'M', 1),
(111, '1', '0-0-', 'N', 1),
(112, '3', '0-0-', '', 1),
(113, '5', '0-0-', 'N', 1),
(114, '6', '0-0-', '', 1),
(115, '7', '0-0-', 'N', 1),
(116, '8', '0-0-', 'N', 1),
(117, '9', '0-0-', 'N', 1),
(118, '10', '0-0-', 'N', 1),
(119, '11', '0-0-', 'N', 1),
(120, '12', '0-0-', '', 1),
(121, '13', '0-0-', '', 1),
(122, '14', '0-0-', '', 1),
(123, '15', '0-0-', '', 1),
(124, '16', '0-0-', '', 1),
(125, '17', '0-0-', '', 1),
(126, '18', '0-0-', '', 1),
(127, '19', '0-0-', '', 1),
(128, '20', '0-0-', 'N', 1),
(129, '21', '0-0-', 'N', 1),
(130, '45', '0-0-', 'A', 1),
(131, '1', '24-5-2019', 'M', 1);

-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE `guru` (
  `idg` int(10) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jk` varchar(3) NOT NULL,
  `alamat` text NOT NULL,
  `idk` int(10) NOT NULL,
  `pass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`idg`, `nip`, `nama`, `jk`, `alamat`, `idk`, `pass`) VALUES
(9, '196105061986032009', 'RETNO UTAMI, M. Pd.', 'P', '-', 10, '77e69c137812518e359196bb2f5e9bb9'),
(10, '195409141979032002', 'Dra. Hj. LATIFAH HANIM', 'P', '-', 10, '77e69c137812518e359196bb2f5e9bb9'),
(11, '195515251977031012', 'Drs. ABDURRAHMAN', 'L', '-', 10, '77e69c137812518e359196bb2f5e9bb9'),
(12, '195703041979031008', 'TJAHJADI HERWANTO, S.Pd', 'L', '-', 11, '77e69c137812518e359196bb2f5e9bb9'),
(13, '196610251998021001		', 'BAMBANG SUPRIYADI, S.Pd', 'L', '-', 11, '77e69c137812518e359196bb2f5e9bb9'),
(14, '5634742645300002', 'M. Rusydi, S.Ag', 'L', '-', 11, '77e69c137812518e359196bb2f5e9bb9'),
(15, '9758760661200012', 'Moh. Basyar, S.Ag', 'L', '-', 11, '77e69c137812518e359196bb2f5e9bb9'),
(16, '9247761662300053', 'Siti Nur Hidayati, M.Ag', 'P', '-', 11, 'd41d8cd98f00b204e9800998ecf8427e'),
(17, '3454756658300033', 'Dani Wahyudi, S.Pd', 'L', '-', 11, '77e69c137812518e359196bb2f5e9bb9'),
(18, '3462742646200013', 'Drs. Masrur', 'L', '-', 11, '77e69c137812518e359196bb2f5e9bb9'),
(19, '7242747649300083', 'Drs. Syarifuddin', 'L', '-', 12, '77e69c137812518e359196bb2f5e9bb9'),
(20, '6546746649200033', 'ENDANG PRISTIAWATY, S.Psi', 'P', '-', 12, '77e69c137812518e359196bb2f5e9bb9'),
(21, '4435735637200023', 'IRMA SURYANI, S.Pd', 'P', '-', 12, '77e69c137812518e359196bb2f5e9bb9'),
(22, '2733762663210162', 'Fathurrofiq, S.Pd', 'L', '-', 12, '77e69c137812518e359196bb2f5e9bb9'),
(23, '1736762663200092', 'Fathurrohman, ST.', 'L', '-', 12, '77e69c137812518e359196bb2f5e9bb9'),
(24, '7054747649300033', 'Drs. Ahmad Wahyudin Effendi', 'L', '-', 12, '77e69c137812518e359196bb2f5e9bb9'),
(25, '7437758661300003', 'Syaifuddin, Msi', 'L', '-', 12, '77e69c137812518e359196bb2f5e9bb9'),
(26, '4061758660300033', 'Yusuf Effendi, S.Ag', 'L', '-', 11, '77e69c137812518e359196bb2f5e9bb9'),
(27, '0655735636200012', 'Moh. Nur Khasan, M.Ag', 'L', '-', 10, '77e69c137812518e359196bb2f5e9bb9'),
(28, '1736762663200098', 'Abdul Fattah, M.Pd', 'L', 'PERUM MSI (Muara Sarana Indah) No 14. Dau Malang', 10, '77e69c137812518e359196bb2f5e9bb9');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id_jadwal` int(10) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `guru` varchar(30) NOT NULL,
  `mapel` varchar(30) NOT NULL,
  `hari` varchar(10) NOT NULL,
  `jam_ke` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id_jadwal`, `kelas`, `guru`, `mapel`, `hari`, `jam_ke`) VALUES
(1, 'XII', 'Didik', 'Bahasa Indonesia', 'Senin', '2'),
(2, 'XII', 'Didik', 'Bahasa Indonesia', 'Selasa', '1'),
(3, 'XI', 'Iqbal', 'Bahasa Indonesia', 'Senin', '3');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `idk` int(10) NOT NULL,
  `id` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`idk`, `id`, `nama`) VALUES
(10, 2, 'XII'),
(11, 2, 'XIII'),
(12, 2, 'IX'),
(13, 3, 'X TKJ 3'),
(14, 3, 'XII');

-- --------------------------------------------------------

--
-- Table structure for table `pelajaran`
--

CREATE TABLE `pelajaran` (
  `id` int(30) NOT NULL,
  `kd_mapel` varchar(10) NOT NULL,
  `nama_mapel` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelajaran`
--

INSERT INTO `pelajaran` (`id`, `kd_mapel`, `nama_mapel`) VALUES
(2, 'mkk1', 'ppkn2'),
(3, 'mkk1', 'ipa');

-- --------------------------------------------------------

--
-- Table structure for table `sekolah`
--

CREATE TABLE `sekolah` (
  `id` int(10) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sekolah`
--

INSERT INTO `sekolah` (`id`, `kode`, `nama`, `alamat`) VALUES
(2, '2010902872872', 'Madrasah Tsanawiyah Wahid Hasyim', 'Jl. Raya Mulyoagung No 51A Dau Malang2'),
(3, '12345', 'SMK Dewantara 2', 'Tegaldanas');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `ids` int(10) NOT NULL,
  `nis` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tempat_lhr` varchar(20) NOT NULL,
  `tgl_lhr` varchar(30) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `jk` varchar(2) NOT NULL,
  `alamat` text NOT NULL,
  `idk` int(5) NOT NULL,
  `tlp` varchar(20) NOT NULL,
  `bapak` varchar(50) NOT NULL,
  `k_bapak` varchar(50) NOT NULL,
  `ibu` varchar(50) NOT NULL,
  `k_ibu` varchar(50) NOT NULL,
  `pass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`ids`, `nis`, `nama`, `tempat_lhr`, `tgl_lhr`, `agama`, `jk`, `alamat`, `idk`, `tlp`, `bapak`, `k_bapak`, `ibu`, `k_ibu`, `pass`) VALUES
(1, '123456789', 'Agus Prayitno', 'Karanganyar', '17-10-1996', 'Islam', 'L', 'gempolan kerjo karanganyar', 10, '8977055336', 'ahmad', '-', 'yati', '-', 'bcd724d15cde8c47650fda962968f102'),
(2, '9965309258', 'Alfaiz Faroko', '', '', '', 'L', '-', 11, '81332036346', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(3, '9985108328', 'Ali Sujana	', '', '', '', 'L', '-', 10, '85733743907', '-', '-', '-', '-', '827ccb0eea8a706c4c34a16891f84e7b'),
(5, '9974601836', 'Ari Nur Fajarullah', '', '', '', 'L', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(6, '9985108364', 'Arifin', '', '', '', 'L', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(7, '9965309342', 'Bahrul Latif	', '', '', '', 'L', '-', 10, '85954590935', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(8, '9974601924', 'Dedy', '', '', '', 'L', '-', 10, '85954590935', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(9, '9974601993', 'Dimas Khozinatul Asrori', '', '', '', 'L', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(10, '9974602034', 'Eviana', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(11, '9974602051', 'Galih Setiawan Susanto', '', '', '', 'L', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(12, '9974602083', 'Hasna Nur Karimah', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(13, '9974602096', 'Herlina Suci Hardianti', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(14, '9985108630', 'Ida Wachyuni', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(15, '9985108634', 'Iin Maryamah', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(16, '9974622339', 'Ina Chintya', '', '', '', 'L', 'Ina Chintya', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(17, '9974603046', 'Indah Dwi Utami', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(18, '9985109207', 'Jamingun Sobri', '', '', '', 'L', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(19, '9974603238', 'Laelatul Badriyah', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(20, '9965320731', 'Lulu Apriliyani', '', '', '', 'P', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(21, '9965320734', 'Muhamad Usman Nawawi', '', '', '', 'L', '-', 10, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(23, '9974603377', 'Aji Supriyanto', '', '', '', 'L', '-', 11, '85954590935', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(24, '9985109537', 'Anisa Safitri', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(25, '9985109543', 'Anjar Nur Faozan', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(27, '9965320857', 'Bani', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(28, '9974603400', 'Catur Fajri Ramadhan', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(29, '9965320870', 'Dimas Inggrit Wijanarko', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(30, '9965320876', 'Dwi Utomo', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(31, '9965320883', 'Efi Nur Cahyani', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(32, '9974603414', 'Eka Sutikno', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(33, '9965320887', 'Endri Isnanto', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(34, '9965320890', 'Evi Nuryanti', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(35, '9985109574', 'Fia Rahayu', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(36, '9965320905', 'Fika Septiana', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(37, '9974603422', 'Herlina Priyatin	', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(38, '9965320922', 'Ika Nur Fajriah', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(39, '9974603436', 'Iwan Nugroho', '', '', '', 'L', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(40, '9974603447', 'Kasroh', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(41, '9974603560', 'Nining Purwaningsih	', '', '', '', 'P', '-', 11, '85954590935', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(42, '9974603593', 'Nofiatun', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(43, '9965321268', 'Nur Khafidin', '', '', '', 'P', '-', 11, '85954590935', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(44, '9974603623', 'Nurul Khusnan', '', '', '', 'P', '-', 11, '85733743907', '-', '-', '-', '-', 'bcd724d15cde8c47650fda962968f102'),
(45, '9965309250', 'Moh. Ali Rohim Sihombing', '', '', '', 'L', 'Jl. Raya Jetis No. 08 Dau Malang', 10, '85954590935', 'Mutasim', 'Petani', 'Rahma', 'Wirausaha', 'bcd724d15cde8c47650fda962968f102'),
(46, '181910087', 'Imas Nurhayati', '', '', '', 'P', 'Kampung panyosogan', 13, '85770466147', 'Ironman', 'Avenger4', 'Black widow', 'Avenger', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `idu` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `pass` text NOT NULL,
  `level` varchar(50) NOT NULL,
  `id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idu`, `nama`, `pass`, `level`, `id`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absen`
--
ALTER TABLE `absen`
  ADD PRIMARY KEY (`ida`);

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`idg`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id_jadwal`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`idk`);

--
-- Indexes for table `pelajaran`
--
ALTER TABLE `pelajaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sekolah`
--
ALTER TABLE `sekolah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`ids`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absen`
--
ALTER TABLE `absen`
  MODIFY `ida` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `guru`
--
ALTER TABLE `guru`
  MODIFY `idg` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id_jadwal` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `idk` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `pelajaran`
--
ALTER TABLE `pelajaran`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sekolah`
--
ALTER TABLE `sekolah`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `ids` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `idu` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;--
-- Database: `tbl_user`
--
CREATE DATABASE IF NOT EXISTS `tbl_user` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tbl_user`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_rec` varchar(17) NOT NULL,
  `user_id` varchar(25) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  `department` varchar(25) NOT NULL,
  `user_sex` varchar(15) NOT NULL,
  `role_admin` varchar(15) NOT NULL,
  `role_user` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_rec`, `user_id`, `user_name`, `password`, `department`, `user_sex`, `role_admin`, `role_user`) VALUES
('20170105135026564', 'asti', 'astimen', '32250170a0dca92', 'Finance', 'Male', 'true', 'false'),
('20170106112608339', 'andi', 'Andika Surya Bakti', 'a', 'Assurance', 'Male', 'false', 'true'),
('20170109140911089', 'ihda', 'ihda husnayain', 'as', 'Delivery', 'Female', 'false', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idu` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idu`);
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
--
-- Database: `user`
--
CREATE DATABASE IF NOT EXISTS `user` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `user`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idu` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idu`, `username`, `password`) VALUES
(1, 'didik', '12345'),
(2, 'iqbal', 'dddd'),
(3, 'candra', '111');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `idu` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;--
-- Database: `volley_upload`
--
CREATE DATABASE IF NOT EXISTS `volley_upload` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `volley_upload`;

-- --------------------------------------------------------

--
-- Table structure for table `volley_upload`
--

CREATE TABLE `volley_upload` (
  `id` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `photo` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `volley_upload`
--

INSERT INTO `volley_upload` (`id`, `name`, `photo`) VALUES
(7, 'tetek', 'http://192.168.10.177/android/upload_image/images/jq3zc1z861xaarfcvcj3.png'),
(8, 'memek', 'http://192.168.10.177/android/upload_image/images/r8k56iif0099bpf1nyr6.png'),
(9, 'kuyuur', 'http://192.168.100.36/replas/images/hb4pu9rw8ytprq2xmkie.png'),
(10, 'kontol', 'http://192.168.100.36/replas/images/6wk7ctac1z8zapwn7d09.png'),
(11, 'uuuuuu', 'http://192.168.100.36/replas/images/gxa92f67ad9ut6stt4qp.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `volley_upload`
--
ALTER TABLE `volley_upload`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `volley_upload`
--
ALTER TABLE `volley_upload`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
